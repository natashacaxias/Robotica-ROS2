import os
import subprocess
import sys

def run_script(path):
    print(f"\n{'='*50}")
    print(f"Running: {path}")
    print(f"{'='*50}\n")
    try:
        subprocess.run([sys.executable, path], check=True)
    except subprocess.CalledProcessError as e:
        print(f"Error running {path}: {e}")
        sys.exit(1)

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    scripts = [
        "ablation/ablation_no_per.py",
        "ablation/ablation_no_stacking.py",
        "ablation/ablation_no_tail_reward.py",
        "ablation/ablation_no_golden_ratio.py",
        "ablation/ablation_no_dueling.py",
        "baselines/baseline_dqn.py",
        "baselines/baseline_apf.py",
        "baselines/baseline_ppo.py",
        "follower_analysis/follower_metrics.py",
        "generate_report.py"
    ]
    
    for script in scripts:
        full_path = os.path.join(base_dir, script)
        if os.path.exists(full_path):
            run_script(full_path)
        else:
            print(f"Warning: Script not found: {full_path}")
            
    print("\nAll experiments completed successfully.")

if __name__ == "__main__":
    main()
