import os
import sys
import torch
import numpy as np
import random

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from trainer import DQNParallelTrainer, TrainConfig
from utils import set_start_easy, set_start_medium, set_start_hard, EvalAgent
from env import LeaderFollowerEnv
from experiments.eval_runner import run_experiment_eval, set_start_generalization

class EnvNoGoldenRatio(LeaderFollowerEnv):
    def __init__(self):
        super().__init__()
        # Substitui proporção áurea por grade uniforme com mesmo K=40 (5 x 8)
        self.v_vals = np.linspace(0.0, 0.5, 5)
        self.w_vals = np.linspace(-1.0, 1.0, 8)
        self.na = len(self.v_vals) * len(self.w_vals)

def main():
    seed = 42
    np.random.seed(seed)
    random.seed(seed)
    torch.manual_seed(seed)
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Starting Ablation No Golden Ratio on {device}")
    
    # Monkey-patch para o Trainer
    import env
    original_env_class = env.LeaderFollowerEnv
    env.LeaderFollowerEnv = EnvNoGoldenRatio
    
    cfg = TrainConfig(seed=seed)
    trainer = DQNParallelTrainer(n_envs=8, cfg=cfg, device=device)
    
    print("Training ablation_no_golden_ratio agent...")
    trainer.train()
    
    env.LeaderFollowerEnv = original_env_class
    
    print("Evaluating ablation_no_golden_ratio agent...")
    policy = trainer.policy
    policy.eval()
    
    agent = EvalAgent(policy, EnvNoGoldenRatio(), device)
    
    scenarios = [
        ("easy", set_start_easy),
        ("medium", set_start_medium),
        ("hard", set_start_hard),
        ("generalization", set_start_generalization)
    ]
    
    results_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'results', 'ablation', 'ablation_no_golden_ratio')
    run_experiment_eval(agent, EnvNoGoldenRatio, scenarios, results_dir, n_episodes=500)

if __name__ == "__main__":
    main()
