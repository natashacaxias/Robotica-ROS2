import os
import sys
import torch
import torch.nn as nn
import numpy as np
import random

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from trainer import DQNParallelTrainer, TrainConfig
from utils import set_start_easy, set_start_medium, set_start_hard, EvalAgent
from env import LeaderFollowerEnv
from experiments.eval_runner import run_experiment_eval, set_start_generalization

class StandardDQN(nn.Module):
    def __init__(self, inp: int, out: int, h: int = 256):
        super().__init__()
        # Extrator de features original
        self.fe = nn.Sequential(
            nn.Linear(inp, h),
            nn.LayerNorm(h),
            nn.ReLU(),
            nn.Linear(h, h),
            nn.LayerNorm(h),
            nn.ReLU(),
            nn.Linear(h, h),
            nn.LayerNorm(h),
            nn.ReLU(),
        )
        
        # Head único sem separação de advantage / value (Ablation No Dueling)
        self.q_head = nn.Sequential(
            nn.Linear(h, h // 2),
            nn.ReLU(),
            nn.Linear(h // 2, out)
        )

    def forward(self, x):
        feat = self.fe(x)
        return self.q_head(feat)

class StandardDQNTrainer(DQNParallelTrainer):
    def __init__(self, n_envs: int, cfg: TrainConfig, device: torch.device):
        super().__init__(n_envs, cfg, device)
        # Substitui a policy pela StandardDQN e move pro device
        obs_dim = self.policy.fe[0].in_features
        self.policy = StandardDQN(obs_dim, self.act_dim).to(device)
        self.target = StandardDQN(obs_dim, self.act_dim).to(device)
        self.target.load_state_dict(self.policy.state_dict())
        
        # Recria o otimizador para os novos parâmetros
        import torch.optim as optim
        self.opt = optim.Adam(self.policy.parameters(), lr=cfg.lr)

def main():
    seed = 42
    np.random.seed(seed)
    random.seed(seed)
    torch.manual_seed(seed)
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Starting Ablation No Dueling on {device}")
    
    cfg = TrainConfig(seed=seed)
    trainer = StandardDQNTrainer(n_envs=8, cfg=cfg, device=device)
    
    print("Training ablation_no_dueling agent...")
    trainer.train()
    
    print("Evaluating ablation_no_dueling agent...")
    policy = trainer.policy
    policy.eval()
    
    agent = EvalAgent(policy, LeaderFollowerEnv(), device)
    
    scenarios = [
        ("easy", set_start_easy),
        ("medium", set_start_medium),
        ("hard", set_start_hard),
        ("generalization", set_start_generalization)
    ]
    
    results_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'results', 'ablation', 'ablation_no_dueling')
    run_experiment_eval(agent, LeaderFollowerEnv, scenarios, results_dir, n_episodes=500)

if __name__ == "__main__":
    main()
