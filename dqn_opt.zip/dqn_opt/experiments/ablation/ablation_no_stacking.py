import os
import sys
import torch
import numpy as np
import random

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from trainer import DQNParallelTrainer, TrainConfig
from utils import set_start_easy, set_start_medium, set_start_hard, EvalAgent
from env import LeaderFollowerEnv
from experiments.eval_runner import run_experiment_eval, set_start_generalization

class EnvNoStacking(LeaderFollowerEnv):
    def __init__(self):
        super().__init__()
        # Desativa o frame stacking usando apenas o frame atual (st = ot)
        self.stack_size = 1
        import collections
        self.frame_stack = collections.deque(maxlen=self.stack_size)

def main():
    seed = 42
    np.random.seed(seed)
    random.seed(seed)
    torch.manual_seed(seed)
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Starting Ablation No Stacking on {device}")
    
    # Criar um ambiente temporário para pegar as dimensões alteradas
    tmp_env = EnvNoStacking()
    # Para DQNParallelTrainer, precisamos que todos os workers usem nossa classe customizada
    # No entanto, DQNParallelTrainer instancia LeaderFollowerEnv hardcoded.
    # Como não podemos modificar o original, faremos o monkey-patching antes de instanciar o trainer
    import env
    original_env_class = env.LeaderFollowerEnv
    env.LeaderFollowerEnv = EnvNoStacking
    
    cfg = TrainConfig(seed=seed)
    trainer = DQNParallelTrainer(n_envs=8, cfg=cfg, device=device)
    
    # Treinar
    print("Training ablation_no_stacking agent...")
    trainer.train()
    
    # Restaurar
    env.LeaderFollowerEnv = original_env_class
    
    # Avaliação
    print("Evaluating ablation_no_stacking agent...")
    policy = trainer.policy
    policy.eval()
    
    agent = EvalAgent(policy, EnvNoStacking(), device)
    
    scenarios = [
        ("easy", set_start_easy),
        ("medium", set_start_medium),
        ("hard", set_start_hard),
        ("generalization", set_start_generalization)
    ]
    
    results_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'results', 'ablation', 'ablation_no_stacking')
    run_experiment_eval(agent, EnvNoStacking, scenarios, results_dir, n_episodes=500)

if __name__ == "__main__":
    main()
