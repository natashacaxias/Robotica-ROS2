import os
import sys
import torch
import numpy as np
import random

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from trainer import DQNParallelTrainer, TrainConfig
from utils import set_start_easy, set_start_medium, set_start_hard, EvalAgent
from env import LeaderFollowerEnv
from experiments.eval_runner import run_experiment_eval, set_start_generalization

class EnvNoTailReward(LeaderFollowerEnv):
    def step(self, action: int):
        # Chama a implementação original
        stacked_st, reward, done, info = super().step(action)
        
        # Elimina o componente w_delta da função de recompensa recalculando-o e adicionando de volta
        # rtail_safety estava sendo subtraído no construtor
        w_delta = abs(self.w_leader - self.last_w_leader) # no super().step o w_leader já virou o last_w_leader
        # Wait, super() modifies last_w_leader. 
        # But for ablation, we can just zero out the tail_reward by re-adding it.
        # Let's override completely to be safe.
        pass

    # A better approach given Python's super is to just overwrite step entirely or just restore the part 
    # Since we can't easily undo state mutations, let's copy the `step` method from `LeaderFollowerEnv` 
    # and remove the rtail_safety component.
    def step(self, action: int):
        self.step_count += 1
        vi = action // 8
        wi = action % 8
        v, w = self.v_vals[vi], self.w_vals[wi]
        self.leader, l_collided = self._step_uni(self.leader, v, w)
        self.v_leader, self.w_leader = v, w
        self.buffer.append(self.leader[:2].copy())
        idx = max(0, len(self.buffer) - 1 - self.delay)
        vf, wf = self._foll_ctrl(self.follower, self.buffer[idx])
        self.follower, f_collided = self._step_uni(self.follower, vf, wf)
        self.v_follower, self.w_follower = vf, wf

        st = self._state()
        dist_target = st[2]
        pair = st[3]
        ang = abs(st[8])

        # ======== RECOMPENSAS NORMALIZADAS ========
        reward = 0.0
        dist_delta = self.last_dist_target - dist_target
        reward += np.clip(5.0 * dist_delta, -1.0, 1.0)
        self.last_dist_target = dist_target
        reward += 0.1 * np.cos(ang)
        reward += 0.2 * self.v_leader * np.cos(ang)
        
        # === ABLATION: ZERAR O COMPONENTE RTAIL_SAFETY ===
        # w_delta = abs(self.w_leader - self.last_w_leader)
        # if w_delta > 0.8:
        #     reward -= 3.0 * w_delta
        # else:
        #     reward -= 0.15 * w_delta
            
        self.last_v_leader = self.v_leader
        self.last_w_leader = self.w_leader

        dist_err = abs(pair - self.desired_dist)
        reward -= 0.3 * min(dist_err, 1.0)
        if dist_err < 0.15: reward += 0.1

        heading_diff = abs(self.wrap(self.leader[2] - self.follower[2]))
        reward -= 0.1 * heading_diff

        if pair < self.min_safe_dist:
            reward -= 2.0 * (self.min_safe_dist - pair)**2

        min_lidar = min(st[15:]) 
        if min_lidar < 0.33: 
            reward -= 0.5 * (1.0 - min_lidar)**4 

        safety_margin = self.collision_dist / 2.0 + 0.15
        fx, fy = self.follower[0], self.follower[1]
        f_near_wall = self._collides_room_walls(fx, fy)
        f_near_inner = self._collides_inner_wall((fx, fy), (fx, fy))
        f_near_pillars = self._collides_pillars(fx, fy)

        if f_near_wall or f_near_inner or f_near_pillars:
            reward -= 0.5

        if not self.passed_breach and self._is_through_breach(self.leader[0], self.leader[1]):
            self.passed_breach = True
            tx, ty = self._get_target()
            self.last_dist_target = np.hypot(tx - self.leader[0], ty - self.leader[1])
            self.frame_stack.append(st)
            return self._get_stacked_state(), 10.0, False, {"checkpoint": "breach"}
            
        if self.passed_breach and not self.passed_door and self._is_through_door(self.leader[0], self.leader[1]):
            self.passed_door = True
            tx, ty = self._get_target()
            self.last_dist_target = np.hypot(tx - self.leader[0], ty - self.leader[1])
            self.frame_stack.append(st)
            return self._get_stacked_state(), 20.0, False, {"checkpoint": "door"}

        self.frame_stack.append(st)
        stacked_st = self._get_stacked_state()

        mx, my = self.goal
        dist_final = np.hypot(mx - self.leader[0], my - self.leader[1])
        if dist_final < 0.3:
            r_final = 50.0
            if abs(self.leader[1] - my) < 0.2: r_final += 10.0
            return stacked_st, r_final, True, {"reason": "passed_goal"}

        if l_collided or f_collided:
            return stacked_st, -100.0, True, {"reason": "wall_collision"}

        if pair < self.collision_dist: 
            return stacked_st, -100.0, True, {"reason": "collision"}

        if self.step_count >= self.max_steps:
            return stacked_st, -5.0, True, {"reason": "timeout"}

        return stacked_st, float(reward), False, {}

def main():
    seed = 42
    np.random.seed(seed)
    random.seed(seed)
    torch.manual_seed(seed)
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Starting Ablation No Tail Reward on {device}")
    
    # Monkey-patch para o Trainer
    import env
    original_env_class = env.LeaderFollowerEnv
    env.LeaderFollowerEnv = EnvNoTailReward
    
    cfg = TrainConfig(seed=seed)
    trainer = DQNParallelTrainer(n_envs=8, cfg=cfg, device=device)
    
    print("Training ablation_no_tail_reward agent...")
    trainer.train()
    
    env.LeaderFollowerEnv = original_env_class
    
    print("Evaluating ablation_no_tail_reward agent...")
    policy = trainer.policy
    policy.eval()
    
    agent = EvalAgent(policy, EnvNoTailReward(), device)
    
    scenarios = [
        ("easy", set_start_easy),
        ("medium", set_start_medium),
        ("hard", set_start_hard),
        ("generalization", set_start_generalization)
    ]
    
    results_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'results', 'ablation', 'ablation_no_tail_reward')
    run_experiment_eval(agent, EnvNoTailReward, scenarios, results_dir, n_episodes=500)

if __name__ == "__main__":
    main()
