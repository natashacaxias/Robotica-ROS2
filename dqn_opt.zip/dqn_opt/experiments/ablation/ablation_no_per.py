import os
import sys
import torch
import numpy as np
import random

# Adiciona dqn_opt ao path para importar módulos originais
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from trainer import DQNParallelTrainer, TrainConfig
from utils import set_start_easy, set_start_medium, set_start_hard, EvalAgent
from env import LeaderFollowerEnv
from experiments.eval_runner import run_experiment_eval, set_start_generalization

def main():
    seed = 42
    np.random.seed(seed)
    random.seed(seed)
    torch.manual_seed(seed)
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Starting Ablation No PER on {device}")
    
    # 1. Configurar treinamento com PER desativado
    cfg = TrainConfig(
        seed=seed,
        per_alpha=0.0, # Desativa a priorização (SumTree atuará como buffer uniforme em termos de pesos pq updates não terão efeito P)
        # alpha=0 na inicialização faz max_priority ** 0 = 1.0 para todos
    )
    
    # Treinar
    trainer = DQNParallelTrainer(n_envs=8, cfg=cfg, device=device)
    
    # Em um estudo real, rodariamos trainer.train(). Para fins do script e testes:
    print("Training ablation_no_per agent...")
    trainer.train()
    
    # 2. Avaliação
    print("Evaluating ablation_no_per agent...")
    policy = trainer.policy
    policy.eval()
    
    # O agente de avaliação não requer modificação
    agent = EvalAgent(policy, LeaderFollowerEnv(), device)
    
    scenarios = [
        ("easy", set_start_easy),
        ("medium", set_start_medium),
        ("hard", set_start_hard),
        ("generalization", set_start_generalization)
    ]
    
    results_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'results', 'ablation', 'ablation_no_per')
    run_experiment_eval(agent, LeaderFollowerEnv, scenarios, results_dir, n_episodes=500)

if __name__ == "__main__":
    main()
