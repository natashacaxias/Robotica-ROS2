import os
import csv
import numpy as np
import time

def set_start_generalization(env):
    """Cenario Generalization: domain randomization ativado (como na fase 3 do treino)."""
    env.domain_rand = True
    env.rand_strength = 1.0  # Máxima randomização
    env.base_gap_size = 2.0
    env.base_door_size = 1.0
    env.collision_dist = env.target_collision_dist
    env.reset()

def run_experiment_eval(agent, env_class, scenarios, results_dir, n_episodes=500):
    """
    Executa avaliação e salva CSV no formato:
    episode, success, collision, time_to_goal, final_dist, progress
    """
    os.makedirs(results_dir, exist_ok=True)
    
    for name, start_fn in scenarios:
        csv_path = os.path.join(results_dir, f"{name}.csv")
        env = env_class()
        
        with open(csv_path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['episode', 'success', 'collision', 'time_to_goal', 'final_dist', 'progress'])
            
            for ep in range(n_episodes):
                env.reset()
                start_fn(env)
                
                initial_state = env._state()
                initial_dist = initial_state[2]
                for _ in range(env.stack_size):
                    env.frame_stack.append(initial_state)
                env.last_dist_target = initial_state[2]
                
                st = env._get_stacked_state()
                done = False
                steps = 0
                info = {}
                
                while not done and steps < 600:
                    a = agent.act(st, greedy=True)
                    st, r, done, info = env.step(a)
                    steps += 1
                
                reason = info.get("reason", "timeout")
                success = 1 if reason == "passed_goal" else 0
                collision = 1 if reason in ["collision", "wall_collision"] else 0
                time_to_goal = steps * env.dt * env.sub if success else np.nan
                
                lx, ly = env.leader[0], env.leader[1]
                gx, gy = env.goal[0], env.goal[1]
                final_dist = np.hypot(gx - lx, gy - ly)
                progress = initial_dist - final_dist
                
                writer.writerow([
                    ep + 1, success, collision, time_to_goal, final_dist, progress
                ])
                
        print(f"[{results_dir}] Saved {name} scenario results to {csv_path}")
