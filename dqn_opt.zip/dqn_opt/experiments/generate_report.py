import os
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

def compute_summary(results_dir):
    """Lê todas as pastas dentro de ablation ou baselines e compila as estatísticas."""
    summaries = []
    
    if not os.path.exists(results_dir):
        return pd.DataFrame()
        
    for agent_name in os.listdir(results_dir):
        agent_dir = os.path.join(results_dir, agent_name)
        if not os.path.isdir(agent_dir):
            continue
            
        successes = []
        collisions = []
        time_to_goal = []
        final_dist = []
        
        for sc in ['easy', 'medium', 'hard', 'generalization']:
            csv_path = os.path.join(agent_dir, f"{sc}.csv")
            if os.path.exists(csv_path):
                df = pd.read_csv(csv_path)
                s = df['success'].mean()
                c = df['collision'].mean()
                t = df['time_to_goal'].mean() # ignore NaN automatically uses non-nan values
                d = df['final_dist'].mean()
                
                successes.append(s)
                collisions.append(c)
                time_to_goal.append(t)
                final_dist.append(d)
                
        if len(successes) > 0:
            summaries.append({
                'Agent': agent_name,
                'Success Rate (%)': np.mean(successes) * 100,
                'Collision Rate (%)': np.mean(collisions) * 100,
                'Avg Time (s)': np.mean(time_to_goal),
                'Avg Final Dist (m)': np.mean(final_dist)
            })
            
    summary_df = pd.DataFrame(summaries)
    if len(summary_df) > 0:
        summary_df.to_csv(os.path.join(results_dir, "summary_table.csv"), index=False)
    return summary_df

def write_latex_table(df, output_path, caption, label):
    """Converte df para LaTeX formatando as colunas e salva no arquivo."""
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    if df.empty:
        return
        
    latex = "\\begin{table}[hbt!]\n"
    latex += "\\centering\n"
    latex += "\\caption{" + caption + "}\n"
    latex += "\\label{" + label + "}\n"
    latex += "\\begin{tabular}{l c c c c}\n"
    latex += "\\toprule\n"
    latex += "Agent & Success (\\%) & Collisions (\\%) & Avg Time (s) & Final Dist (m) \\\\\n"
    latex += "\\midrule\n"
    
    for i, row in df.iterrows():
        latex += f"{row['Agent'].replace('_', '\\_')} & {row['Success Rate (%)']:.1f} & "
        latex += f"{row['Collision Rate (%)']:.1f} & {row['Avg Time (s)']:.1f} & {row['Avg Final Dist (m)']:.2f} \\\\\n"
        
    latex += "\\bottomrule\n"
    latex += "\\end{tabular}\n"
    latex += "\\end{table}\n"
    
    with open(output_path, 'w') as f:
        f.write(latex)
    print(f"LaTeX table saved to {output_path}")

def plot_success_rates(df, output_path, title):
    """Gera gráfico de barras comparativo de success rate."""
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    if df.empty:
        return
        
    plt.figure(figsize=(10, 6))
    bars = plt.bar(df['Agent'], df['Success Rate (%)'], color='skyblue', edgecolor='black')
    plt.ylabel('Success Rate (%)')
    plt.title(title)
    plt.xticks(rotation=45, ha='right')
    plt.ylim(0, 105)
    
    for bar in bars:
        yval = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2.0, yval, f"{yval:.1f}%", va='bottom', ha='center')
        
    plt.tight_layout()
    plt.savefig(output_path, format='pdf')
    plt.close()
    print(f"Plot saved to {output_path}")

def plot_follower_metrics(results_dir, output_path):
    """Gera o plot com as latências para o Seguidor."""
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    follower_dir = os.path.join(results_dir, 'follower')
    
    if not os.path.exists(follower_dir):
        return
        
    plt.figure(figsize=(10, 6))
    
    delays = [0, 2, 4, 6, 8]
    colors = ['blue', 'green', 'orange', 'red', 'purple']
    
    for d, c in zip(delays, colors):
        csv_path = os.path.join(follower_dir, f"formation_error_{d}.csv")
        if os.path.exists(csv_path):
            df = pd.read_csv(csv_path)
            # Smooth data with rolling mean for visibility
            smoothed = df['distance_error'].rolling(window=50, min_periods=1).mean()
            # Plot only first 3000 steps to keep the chart clean (or all if short)
            limit = min(3000, len(smoothed))
            plt.plot(df['step'][:limit], smoothed[:limit], label=f"$\\tau={d}$", color=c, alpha=0.8)
            
    plt.ylabel('Formation Error $|d_{pair} - d_{des}|$ (m)')
    plt.xlabel('Timesteps')
    plt.title('Impact of Communication Delay on Leader-Follower Formation')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(output_path, format='pdf')
    plt.close()
    print(f"Plot saved to {output_path}")

def main():
    base_dir = os.path.join(os.path.dirname(__file__), '..', 'results')
    ablation_dir = os.path.join(base_dir, 'ablation')
    baselines_dir = os.path.join(base_dir, 'baselines')
    
    print("Computing metrics and generating LaTeX tables...")
    df_abl = compute_summary(ablation_dir)
    write_latex_table(df_abl, os.path.join(base_dir, 'tables', 'ablation_table.tex'),
                     "Ablation Study Results", "tab:ablation")
                     
    df_base = compute_summary(baselines_dir)
    write_latex_table(df_base, os.path.join(base_dir, 'tables', 'baseline_table.tex'),
                     "Baseline Comparison Results", "tab:baseline")
                     
    print("Generating PDF figures...")
    plot_success_rates(df_abl, os.path.join(base_dir, 'figures', 'ablation_success_rate.pdf'), 
                      "Ablation Study - Success Rates")
                      
    plot_success_rates(df_base, os.path.join(base_dir, 'figures', 'baseline_comparison.pdf'), 
                      "Baselines - Success Rates")
                      
    plot_follower_metrics(base_dir, os.path.join(base_dir, 'figures', 'follower_formation_error.pdf'))
    
    print("Done! Reports generated at results/tables/ and results/figures/")

if __name__ == "__main__":
    main()
