import os
import sys
import numpy as np

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))
from env import LeaderFollowerEnv
from utils import set_start_easy, set_start_medium, set_start_hard
from experiments.eval_runner import run_experiment_eval, set_start_generalization

class APFAgent:
    def __init__(self):
        self.env = None # Set by evaluators usually, or passed directly
        self.k_att = 1.0
        self.k_rep = 0.5
        self.d0 = 0.8
        
        # O agente APF usa o modelo de ações contínuas para controlar v, w
        # Mas o env original recebe inteiros. 
        # Precisamos mapear v,w calculados pelo APF para a ação discreta mais próxima do env:
        # self.v_vals, self.w_vals em LeaderFollowerEnv
        
    def act(self, state, greedy=True):
        assert self.env is not None, "APFAgent requires env access to get state and action spaces"
        
        # State [108] é [tx-lx, ty-ly, dist_target, pair_dist, sin(Lth), cos(Lth), sin(Fth), cos(Fth), ang, breach, door, p_vl, p_wl, sin_af, cos_af, lidar (x21), previous_frames...]
        # state is stacked. We just need the last frame. Actually, the most recent frame is the first 36 elements?
        # In env.py._get_stacked_state(): np.concatenate(list(self.frame_stack))
        # deque apends to right. So the latest frame is at the end.
        st_size = 36 # 15 + 21
        latest_st = state[-st_size:]
        
        tx_minus_lx = latest_st[0]
        ty_minus_ly = latest_st[1]
        dist_target = latest_st[2]
        
        # Attractive forces (global coordinate space approximation from heading)
        Lth = np.arctan2(latest_st[4], latest_st[5])
        
        f_att_x = self.k_att * tx_minus_lx
        f_att_y = self.k_att * ty_minus_ly
        
        # Repulsive forces (using simulated lidar)
        lidar_data = latest_st[15:36] # 21 values, normalized [0, 1]
        lidar_angles = np.linspace(-np.pi/3, np.pi/3, 21)
        lidar_max_dist = 3.0
        
        f_rep_x = 0.0
        f_rep_y = 0.0
        
        for d_norm, ang in zip(lidar_data, lidar_angles):
            d_real = d_norm * lidar_max_dist
            if d_real < self.d0:
                # Obstacle detected within d0
                # Vector FROM obstacle TO leader
                # Absolute angle of lidar ray: Lth + ang
                ray_angle = Lth + ang
                # Vector from robot to obstacle
                ox = d_real * np.cos(ray_angle)
                oy = d_real * np.sin(ray_angle)
                
                # Derivada do potencial repulsivo
                # U_rep = 0.5 * k_rep * (1/d - 1/d0)^2
                # F_rep = k_rep * (1/d - 1/d0) * (1/d^2) * (-grad(d))
                # F_rep direction is opposite to obstacle -> -ox, -oy normalized
                mag = self.k_rep * (1.0/d_real - 1.0/self.d0) * (1.0/(d_real**2))
                ux = -ox / d_real
                uy = -oy / d_real
                
                f_rep_x += mag * ux
                f_rep_y += mag * uy
                
        f_tot_x = f_att_x + f_rep_x
        f_tot_y = f_att_y + f_rep_y
        
        # Translate Force vector to v, w for unicycle
        des_theta = np.arctan2(f_tot_y, f_tot_x)
        
        # Helper to wrap angle
        def wrap(a): return (a + np.pi) % (2 * np.pi) - np.pi
        
        e_th = wrap(des_theta - Lth)
        v_des = 0.5 * np.cos(e_th) # max v is 0.5, reduce if turning
        w_des = 1.0 * e_th         # P controller for heading
        
        # Discretize Action
        v_des = max(0.0, v_des)
        vi = (np.abs(self.env.v_vals - v_des)).argmin()
        wi = (np.abs(self.env.w_vals - w_des)).argmin()
        
        return vi * 8 + wi

def main():
    print("Starting Baseline APF")
    agent = APFAgent()
    
    # We need to inject the env into the agent before each evaluation
    # To do this cleanly with our run_experiment_eval, we can subclass we inject it in act:
    class APFWrapper:
        def __init__(self, inner):
            self.inner = inner
            self.env = None
        def act(self, st, greedy=True):
            if self.inner.env is None:
                self.inner.env = self.env
            return self.inner.act(st, greedy)
            
    wrapper = APFWrapper(agent)
    
    # Customize run_experiment_eval temporary just to pass env to wrapper
    def run_apf_eval():
        scenarios = [
            ("easy", set_start_easy),
            ("medium", set_start_medium),
            ("hard", set_start_hard),
            ("generalization", set_start_generalization)
        ]
        results_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'results', 'baselines', 'baseline_apf')
        n_episodes = 500
        
        os.makedirs(results_dir, exist_ok=True)
        import csv
        for name, start_fn in scenarios:
            csv_path = os.path.join(results_dir, f"{name}.csv")
            env = LeaderFollowerEnv()
            wrapper.env = env
            wrapper.inner.env = env
            
            with open(csv_path, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['episode', 'success', 'collision', 'time_to_goal', 'final_dist', 'progress'])
                
                for ep in range(n_episodes):
                    env.reset()
                    start_fn(env)
                    
                    initial_state = env._state()
                    initial_dist = initial_state[2]
                    for _ in range(env.stack_size):
                        env.frame_stack.append(initial_state)
                    
                    st = env._get_stacked_state()
                    done = False
                    steps = 0
                    info = {}
                    
                    while not done and steps < 600:
                        a = wrapper.act(st)
                        st, r, done, info = env.step(a)
                        steps += 1
                    
                    reason = info.get("reason", "timeout")
                    success = 1 if reason == "passed_goal" else 0
                    collision = 1 if reason in ["collision", "wall_collision"] else 0
                    time_to_goal = steps * env.dt * env.sub if success else np.nan
                    
                    lx, ly = env.leader[0], env.leader[1]
                    gx, gy = env.goal[0], env.goal[1]
                    final_dist = np.hypot(gx - lx, gy - ly)
                    progress = initial_dist - final_dist
                    
                    writer.writerow([
                        ep + 1, success, collision, time_to_goal, final_dist, progress
                    ])
                    
            print(f"[{results_dir}] Saved {name} scenario results to {csv_path}")

    run_apf_eval()

if __name__ == "__main__":
    main()
