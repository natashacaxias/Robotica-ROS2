import os
import sys
import torch
import torch.nn as nn
import numpy as np
import random

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from trainer import DQNParallelTrainer, TrainConfig
from utils import set_start_easy, set_start_medium, set_start_hard, EvalAgent
from env import LeaderFollowerEnv
from experiments.eval_runner import run_experiment_eval, set_start_generalization

class BaselineDQN(nn.Module):
    def __init__(self, inp: int, out: int, h: int = 256):
        super().__init__()
        self.fe = nn.Sequential(
            nn.Linear(inp, h),
            nn.LayerNorm(h),
            nn.ReLU(),
            nn.Linear(h, h),
            nn.LayerNorm(h),
            nn.ReLU(),
            nn.Linear(h, h),
            nn.LayerNorm(h),
            nn.ReLU(),
        )
        self.q_head = nn.Sequential(
            nn.Linear(h, h // 2),
            nn.ReLU(),
            nn.Linear(h // 2, out)
        )

    def forward(self, x):
        feat = self.fe(x)
        return self.q_head(feat)

class BaselineDQNTrainer(DQNParallelTrainer):
    def __init__(self, n_envs: int, cfg: TrainConfig, device: torch.device):
        super().__init__(n_envs, cfg, device)
        obs_dim = self.policy.fe[0].in_features
        self.policy = BaselineDQN(obs_dim, self.act_dim).to(device)
        self.target = BaselineDQN(obs_dim, self.act_dim).to(device)
        self.target.load_state_dict(self.policy.state_dict())
        import torch.optim as optim
        self.opt = optim.Adam(self.policy.parameters(), lr=cfg.lr)

def main():
    seed = 42
    np.random.seed(seed)
    random.seed(seed)
    torch.manual_seed(seed)
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Starting Baseline DQN on {device}")
    
    cfg = TrainConfig(seed=seed)
    trainer = BaselineDQNTrainer(n_envs=8, cfg=cfg, device=device)
    
    print("Training baseline_dqn agent...")
    trainer.train()
    
    print("Evaluating baseline_dqn agent...")
    policy = trainer.policy
    policy.eval()
    
    agent = EvalAgent(policy, LeaderFollowerEnv(), device)
    
    scenarios = [
        ("easy", set_start_easy),
        ("medium", set_start_medium),
        ("hard", set_start_hard),
        ("generalization", set_start_generalization)
    ]
    
    results_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'results', 'baselines', 'baseline_dqn')
    run_experiment_eval(agent, LeaderFollowerEnv, scenarios, results_dir, n_episodes=500)

if __name__ == "__main__":
    main()
