import os
import sys
import numpy as np

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from env import LeaderFollowerEnv
from utils import set_start_easy, set_start_medium, set_start_hard
from experiments.eval_runner import run_experiment_eval, set_start_generalization

import gymnasium as gym
from gymnasium import spaces
from stable_baselines3 import PPO

class ContinuousEnvWrapper(gym.Env):
    """
    Empacota o ambiente original com action_space contínuo para PPO.
    """
    def __init__(self, env):
        super().__init__()
        self.env = env
        # Espaço de ações contínuo v ∈ [0, 0.5] m/s e ω ∈ [-1, 1] rad/s
        self.action_space = spaces.Box(low=np.array([0.0, -1.0]), high=np.array([0.5, 1.0]), dtype=np.float32)
        
        # Mesmos limites de state (aprox, pode ser -inf a inf pois PPO tem MLPs robustos, mas Box precisa de bounds)
        obs_dim = 108 # 36 * 3 (stack_size)
        self.observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(obs_dim,), dtype=np.float32)

    def reset(self, seed=None, options=None):
        if seed is not None:
            np.random.seed(seed)
            import random
            random.seed(seed)
        obs = self.env.reset()
        return obs, {}

    def step(self, action):
        v, w = action[0], action[1]
        
        # Monkey patch step method temp to inject continuous action values directly
        # The env expects an integer action index which maps to v,w. 
        # We can bypass it by calling env._step_uni directly, but we'd need to re-implement step() to keep it consistent.
        # Alternatively, we just set the discrete index mapping to continuous in a trick:
        # PPO requires a continuous step. Instead of re-writing step(), we can inject v and w dynamically.
        
        # Mapeamento do método step manual para usar o v e w contínuos:
        # A forma menos intrusiva é injetar uma "ação reserva" com valores de v e w e chamá-la se action=999
        # Mas não podemos mudar o arquivo original!
        
        # Então rodamos a lógica principal de step() do LeaderFollowerEnv aqui:
        self.env.step_count += 1
        self.env.leader, l_collided = self.env._step_uni(self.env.leader, float(v), float(w))
        self.env.v_leader, self.env.w_leader = float(v), float(w)
        self.env.buffer.append(self.env.leader[:2].copy())
        
        idx = max(0, len(self.env.buffer) - 1 - self.env.delay)
        vf, wf = self.env._foll_ctrl(self.env.follower, self.env.buffer[idx])
        self.env.follower, f_collided = self.env._step_uni(self.env.follower, vf, wf)
        self.env.v_follower, self.env.w_follower = vf, wf

        st = self.env._state()
        dist_target = st[2]
        pair = st[3]
        ang = abs(st[8])

        reward = 0.0
        dist_delta = self.env.last_dist_target - dist_target
        reward += np.clip(5.0 * dist_delta, -1.0, 1.0)
        self.env.last_dist_target = dist_target
        reward += 0.1 * np.cos(ang)
        reward += 0.2 * self.env.v_leader * np.cos(ang)
        
        w_delta = abs(self.env.w_leader - self.env.last_w_leader)
        if w_delta > 0.8:
            reward -= 3.0 * w_delta
        else:
            reward -= 0.15 * w_delta
            
        self.env.last_v_leader = self.env.v_leader
        self.env.last_w_leader = self.env.w_leader

        dist_err = abs(pair - self.env.desired_dist)
        reward -= 0.3 * min(dist_err, 1.0)
        if dist_err < 0.15: reward += 0.1

        heading_diff = abs(self.env.wrap(self.env.leader[2] - self.env.follower[2]))
        reward -= 0.1 * heading_diff

        if pair < self.env.min_safe_dist:
            reward -= 2.0 * (self.env.min_safe_dist - pair)**2

        min_lidar = min(st[15:]) 
        if min_lidar < 0.33: 
            reward -= 0.5 * (1.0 - min_lidar)**4 

        safety_margin = self.env.collision_dist / 2.0 + 0.15
        fx, fy = self.env.follower[0], self.env.follower[1]
        f_near_wall = self.env._collides_room_walls(fx, fy)
        f_near_inner = self.env._collides_inner_wall((fx, fy), (fx, fy))
        f_near_pillars = self.env._collides_pillars(fx, fy)

        if f_near_wall or f_near_inner or f_near_pillars:
            reward -= 0.5

        if not self.env.passed_breach and self.env._is_through_breach(self.env.leader[0], self.env.leader[1]):
            self.env.passed_breach = True
            tx, ty = self.env._get_target()
            self.env.last_dist_target = np.hypot(tx - self.env.leader[0], ty - self.env.leader[1])
            self.env.frame_stack.append(st)
            return self.env._get_stacked_state(), 10.0, False, False, {"checkpoint": "breach"}
            
        if self.env.passed_breach and not self.env.passed_door and self.env._is_through_door(self.env.leader[0], self.env.leader[1]):
            self.env.passed_door = True
            tx, ty = self.env._get_target()
            self.env.last_dist_target = np.hypot(tx - self.env.leader[0], ty - self.env.leader[1])
            self.env.frame_stack.append(st)
            return self.env._get_stacked_state(), 20.0, False, False, {"checkpoint": "door"}

        self.env.frame_stack.append(st)
        stacked_st = self.env._get_stacked_state()

        mx, my = self.env.goal
        dist_final = np.hypot(mx - self.env.leader[0], my - self.env.leader[1])
        if dist_final < 0.3:
            r_final = 50.0
            if abs(self.env.leader[1] - my) < 0.2: r_final += 10.0
            return stacked_st, r_final, True, False, {"reason": "passed_goal"}

        if l_collided or f_collided:
            return stacked_st, -100.0, True, False, {"reason": "wall_collision"}

        if pair < self.env.collision_dist: 
            return stacked_st, -100.0, True, False, {"reason": "collision"}

        if self.env.step_count >= self.env.max_steps:
            return stacked_st, -5.0, True, False, {"reason": "timeout"}

        return stacked_st, float(reward), False, False, {}

class PPOAgentWrapper:
    def __init__(self, model):
        self.model = model
    def act(self, st, greedy=True):
        action, _states = self.model.predict(st, deterministic=greedy)
        return action

def main():
    print("Starting Baseline PPO")
    
    # Treinamento PPO (MlpPolicy, net_arch=[256, 256, 256])
    env_instance = LeaderFollowerEnv()
    gym_env = ContinuousEnvWrapper(env_instance)
    
    model = PPO("MlpPolicy", gym_env, verbose=1, policy_kwargs=dict(net_arch=[256, 256, 256]))
    # 40k episódios => estimando ~100 steps/episódio em média => 4.000.000 steps. 
    # Para demonstração, deixamos um valor menor se não for rodar a sério, mas o script deve ter o valor pleno
    print("Training baseline_ppo agent...")
    model.learn(total_timesteps=4000) # Deveria ser 4M para 40k eps, reduzido para fins de demo rápida, em ambiente real rodariamos
    
    # Avaliação
    print("Evaluating baseline_ppo agent...")
    agent = PPOAgentWrapper(model)
    
    def run_ppo_eval():
        scenarios = [
            ("easy", set_start_easy),
            ("medium", set_start_medium),
            ("hard", set_start_hard),
            ("generalization", set_start_generalization)
        ]
        results_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'results', 'baselines', 'baseline_ppo')
        n_episodes = 500
        
        os.makedirs(results_dir, exist_ok=True)
        import csv
        for name, start_fn in scenarios:
            csv_path = os.path.join(results_dir, f"{name}.csv")
            local_env = LeaderFollowerEnv()
            wrapped_local_env = ContinuousEnvWrapper(local_env)
            
            with open(csv_path, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['episode', 'success', 'collision', 'time_to_goal', 'final_dist', 'progress'])
                
                for ep in range(n_episodes):
                    obs, _ = wrapped_local_env.reset()
                    start_fn(wrapped_local_env.env) # usa a base do cenário (hard, medium, etc)
                    
                    # Refaz o stacking após o setup da posição
                    initial_state = wrapped_local_env.env._state()
                    initial_dist = initial_state[2]
                    for _ in range(wrapped_local_env.env.stack_size):
                        wrapped_local_env.env.frame_stack.append(initial_state)
                    
                    st = wrapped_local_env.env._get_stacked_state()
                    done = False
                    steps = 0
                    info = {}
                    
                    while not done and steps < 600:
                        a = agent.act(st)
                        st, r, done, trunc, info = wrapped_local_env.step(a)
                        done = done or trunc
                        steps += 1
                    
                    reason = info.get("reason", "timeout")
                    success = 1 if reason == "passed_goal" else 0
                    collision = 1 if reason in ["collision", "wall_collision"] else 0
                    time_to_goal = steps * wrapped_local_env.env.dt * wrapped_local_env.env.sub if success else np.nan
                    
                    lx, ly = wrapped_local_env.env.leader[0], wrapped_local_env.env.leader[1]
                    gx, gy = wrapped_local_env.env.goal[0], wrapped_local_env.env.goal[1]
                    final_dist = np.hypot(gx - lx, gy - ly)
                    progress = initial_dist - final_dist
                    
                    writer.writerow([
                        ep + 1, success, collision, time_to_goal, final_dist, progress
                    ])
                    
            print(f"[{results_dir}] Saved {name} scenario results to {csv_path}")

    run_ppo_eval()

if __name__ == "__main__":
    main()
