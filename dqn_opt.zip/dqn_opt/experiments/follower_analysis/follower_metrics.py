import os
import sys
import torch
import numpy as np
import csv

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))
from env import LeaderFollowerEnv
from utils import EvalAgent, set_start_easy, set_start_medium, set_start_hard
from experiments.eval_runner import set_start_generalization
from model import DuelingDQN

def main():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("Starting Follower Analysis")
    
    # Load best model
    model_path = os.path.join(os.path.dirname(__file__), '..', '..', 'best_model.pth')
    if not os.path.exists(model_path):
        model_path = os.path.join(os.path.dirname(__file__), '..', '..', 'model.pth')
        
    env = LeaderFollowerEnv()
    obs_dim = 108
    policy = DuelingDQN(obs_dim, env.na).to(device)
    if os.path.exists(model_path):
        policy.load_state_dict(torch.load(model_path, map_location=device, weights_only=True))
    else:
        print(f"Warning: Model not found at {model_path}, using random weights")
    policy.eval()
    
    agent = EvalAgent(policy, env, device)
    delays = [0, 2, 4, 6, 8]
    
    results_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'results', 'follower')
    os.makedirs(results_dir, exist_ok=True)
    
    # Vamos rodar em Generalization para testar a robustez real
    start_fn = set_start_generalization
    
    for delay in delays:
        csv_path = os.path.join(results_dir, f"formation_error_{delay}.csv")
        
        with open(csv_path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['step', 'distance_error', 'heading_error'])
            
            # Vamos rodar 10 episódios e agregar os passos sequencialmente 
            # ou apenas 1 episódio longo se referir (rodaremos 10 p/ juntar dados)
            episodes = 10
            total_steps_recorded = 0
            
            for ep in range(episodes):
                env.reset()
                start_fn(env)
                env.delay = delay # Override a latência de comunicação
                
                initial_state = env._state()
                for _ in range(env.stack_size):
                    env.frame_stack.append(initial_state)
                env.last_dist_target = initial_state[2]
                
                st = env._get_stacked_state()
                done = False
                steps = 0
                
                while not done and steps < 600:
                    a = agent.act(st, greedy=True)
                    st, r, done, info = env.step(a)
                    steps += 1
                    
                    # Compute Errors
                    lx, ly, lth = env.leader
                    fx, fy, fth = env.follower
                    pair_dist = np.hypot(lx - fx, ly - fy)
                    
                    dist_err = abs(pair_dist - env.desired_dist)
                    head_err = abs(env.wrap(lth - fth))
                    
                    writer.writerow([total_steps_recorded, dist_err, head_err])
                    total_steps_recorded += 1
                    
        print(f"Finished evaluating delay tau = {delay}, saved to {csv_path}")

if __name__ == "__main__":
    main()
