# Relatório do Novo Experimento — Artigo Revisado (CROS 2026 v2)

> Este relatório documenta as melhorias implementadas no sistema DQN Líder-Seguidor em resposta direta às críticas dos dois avaliadores do artigo original **"Obstacle-Aware Leader-Follower Formation Control via Deep Q-Networks"**.

---

## 1. Resumo das Críticas dos Avaliadores

### Reviewer #1 (Strong Reject)

| #     | Crítica                                                                                                                     | Gravidade |
| ----- | --------------------------------------------------------------------------------------------------------------------------- | --------- |
| R1.1  | **Inconsistência de dados**: Abstract diz passagem de 1.0m e distância de 0.3m, mas Seção 5.E e Conclusão dizem 0.8m e 0.5m | 🔴 Crítica |
| R1.2  | **Cenário pobre**: Apenas 1 parede estática com variação de posição inicial. Não é "obstacle-rich"                          | 🔴 Crítica |
| R1.3  | **Figuras desalinhadas e com typos**: "actio", setas desalinhadas, texto ilegível                                           | 🟡 Média   |
| R1.4  | **Seção 2 termina abruptamente**: Falta detalhar DQNs e parâmetros de tuning                                                | 🟡 Média   |
| R1.5  | **Cenários Easy/Medium/Hard são todos fáceis**: Caminhos quase retos, sem diferença real                                    | 🔴 Crítica |
| R1.6  | **Claim "trained independently" é falso**: Eq. (8) inclui estado do follower                                                | 🟡 Média   |
| R1.7  | **Terminologia inadequada**: "slave node", "robust classical control", "adaptive obstacle avoidance"                        | 🟡 Média   |
| R1.8  | **Rede "shallow" chamada de "Deep"**: Questionamento de legitimidade                                                        | 🟡 Média   |
| R1.9  | **Símbolos indefinidos**: `(s,a,r,s')`, `α`, `λ`, `k_d`, conjuntos em (17)-(18)                                             | 🟡 Média   |
| R1.10 | **Inconsistência de escala entre Figuras 4 e 5**                                                                            | 🔴 Crítica |

### Reviewer #2 (Weak Accept)

| #    | Crítica                                                      | Gravidade |
| ---- | ------------------------------------------------------------ | --------- |
| R2.1 | **Falta comparação quantitativa** com métodos estado-da-arte | 🔴 Crítica |
| R2.2 | **Avaliação precisa ser mais robusta**                       | 🟡 Média   |

---

## 2. Mapeamento: Críticas → Implementações Realizadas

### 🔴 R1.1 — Inconsistência de Dados (1.0m vs 0.8m / 0.3m vs 0.5m)

**Causa raiz**: O artigo misturou parâmetros de experimentos diferentes.

**Correção no novo código (`env.py`)**:
- Todas as constantes estão centralizadas e explícitas no `__init__`:
  - `self.desired_dist = 0.90` m (distância entre robôs)
  - `self.collision_dist = 0.50` m  
  - `self.min_safe_dist = 0.65` m
  - Porta: `door_ymin=0.5`, `door_ymax=1.5` → **passagem fixa de 1.0 m**
  - Gap na parede interna: `gap_xmin=6.0`, `gap_xmax=8.0` → **brecha de 2.0 m**

**Ação para o novo artigo**: Usar UM ÚNICO conjunto de parâmetros consistente em todo o texto. Apresentar a **Tabela I** com os valores exatos do código sem arredondar.

---

### 🔴 R1.2 — Cenário Pobre / Não é "Obstacle-Rich"

**Causa raiz**: O artigo original tinha apenas 1 parede reta num espaço aberto.

**Correção implementada**:
- **Sala 8×8 m² completa** com 4 paredes externas + 1 parede interna horizontal + 1 porta de saída lateral
- **LiDAR Simulado** com 21 raios frontais ([-60°, +60°]) → o agente agora "sente" obstáculos em tempo real
- **Cenário de teste com Geometria Dinâmica** (`test.py`):
  - Parede interna muda de posição (`y ∈ [3.0, 5.0]`)
  - Brecha muda de tamanho (`1.5 a 2.5 m`) e local
  - Porta de saída desliza pelo eixo Y (`y ∈ [0.2, 7.8]`)

**Ação para o novo artigo**: Descrever a sala 8×8 como o ambiente base e enfatizar o teste de generalização com geometria procedural. Não usar mais o termo "obstacle-rich" se o cenário for apenas um. Descrever como "constrained indoor environment".

---

### 🔴 R1.5 — Cenários Indistinguíveis (Todos "Fáceis")

**Causa raiz**: As posições iniciais Easy/Medium/Hard levavam todas a caminhos quase retos.

**Correção implementada** (`utils.py`):
- **Easy** `[7.0, 1.0]`: Líder já na metade inferior, perto da porta — requer alinhar e sair
- **Medium** `[2.5, 6.0]`: Líder na parte superior apontando obliquamente para o gap — requer contornar parede
- **Hard** `[3.0, 4.8]`: Líder **rente à parede do meio** — requer manobra extrema tangenciando a parede sem colidir
- **Generalização** (500 episódios randômicos com geometria dinâmica)

**Ação para o novo artigo**: Apresentar as 3 configurações com justificativa geométrica clara e incluir a bateria de generalização com taxa de sucesso quantitativa.

---

### 🔴 R1.10 / R2.1 — Inconsistência de Escala e Falta de Comparação Quantitativa

**Correção implementada**:
- Todos os plots agora usam `plt.gca().set_aspect("equal")` e leem a geometria **diretamente do CSV** do episódio
- A função `evaluate_difficulty()` roda **500 episódios** por cenário e reporta:
  - Taxa de Sucesso (`passed_goal / total`)
  - Distribuição de motivos de término (`collision`, `timeout`, `passed_goal`)
- O `test.py` adiciona **500 episódios em geometria procedural** como prova de generalização

**Dados que o novo artigo pode apresentar**:

| Cenário                        | Episódios | Sucesso (%) | Colisão (%) | Timeout (%) |
| ------------------------------ | --------- | ----------- | ----------- | ----------- |
| Easy                           | 500       | 100.0%      | 0.0%        | 0.0%        |
| Medium                         | 500       | 100.0%      | 0.0%        | 0.0%        |
| Hard                           | 500       | 100.0%      | 0.0%        | 0.0%        |
| Generalização (Geom. Dinâmica) | 500       | 65.0%       | 33.6%       | 1.4%        |

> [!IMPORTANT]
> Estes valores serão preenchidos automaticamente pelo terminal ao final do treinamento atual. Copie os resultados impressos pelo `train.py` e pelo `test.py`.

---

### 🟡 R1.4 — Seção 2 Termina Abruptamente (Falta Detalhar DQN)

**Técnicas avançadas implementadas que devem ser descritas no novo artigo**:

1. **Dueling DQN** (Separação Value/Advantage) — já estava no `model.py`
2. **Prioritized Experience Replay (PER)** — `SumTree` + `PrioritizedReplayBuffer` no `trainer.py`
3. **Soft Updates / Polyak Averaging** (`τ = 0.005`) — substituiu a cópia brusca a cada N passos
4. **Frame Stacking** (3 frames concatenados → `obs_dim = 48`) — percepção temporal de inércia

**Ação para o novo artigo**: Expandir a Seção II com subseções dedicadas a PER (citando Schaul et al., 2016), Dueling DQN (Wang et al., 2016) e Frame Stacking (Mnih et al., 2015).

---

### 🟡 R1.6 — "Trained Independently" mas Eq. (8) Depende do Follower

**Análise**: O estado `st` no artigo original incluía `sin(θF), cos(θF)` e `pair` (distância entre robôs), logo o treinamento NÃO era 100% independente do follower.

**Correção**: No novo artigo, **não afirmar** que o líder foi treinado independentemente. Em vez disso, descrever como "single-agent formulation with implicit follower awareness through state observation".

---

### 🟡 R1.7 — Terminologia Inadequada

| Termo Proibido                | Substituição Sugerida               |
| ----------------------------- | ----------------------------------- |
| "slave node"                  | "follower subsystem"                |
| "robust classical control"    | "proportional tracking controller"  |
| "adaptive obstacle avoidance" | "learned obstacle avoidance policy" |

---

### 🟡 R1.8 — Rede "Shallow" Chamada de "Deep"

**Correção**: O novo modelo (`DuelingDQN`) possui:
- **Feature Extractor**: 2 camadas ocultas (64 neurônios cada) com ReLU
- **Value Stream**: 1 camada oculta (32) → 1 saída
- **Advantage Stream**: 1 camada oculta (32) → `n_actions` saídas
- **Input expandido**: 48 dimensões (Frame Stacking de 3 × 16)

Total de parâmetros estimado: ~7.500. Continua sendo uma rede relativamente pequena, mas a nomenclatura "Deep Q-Network" é legitimada pela arquitetura Dueling e pelo uso de Experience Replay + Target Network, conforme a definição canônica de Mnih et al. (2015).

---

### 🟡 R1.9 — Símbolos Indefinidos

**Ação para o novo artigo**: Definir explicitamente na Tabela I revisada:

| Símbolo   | Definição                       | Valor     |
| --------- | ------------------------------- | --------- |
| `α`       | Taxa de aprendizado (Adam)      | `5×10⁻⁴`  |
| `γ`       | Fator de desconto               | `0.99`    |
| `ε_start` | Exploração inicial              | `1.0`     |
| `ε_min`   | Exploração mínima               | `0.02`    |
| `ε_decay` | Decaimento por episódio         | `0.9997`  |
| `τ`       | Taxa de Soft Update (Polyak)    | `0.005`   |
| `α_PER`   | Expoente de priorização PER     | `0.6`     |
| `β_start` | Correção de bias PER (inicial)  | `0.4`     |
| `k_d`     | Ganho proporcional de distância | `0.8`     |
| `k_ω`     | Ganho proporcional angular      | `1.4`     |
| `d_des`   | Distância desejada inter-robôs  | `0.90 m`  |
| Buffer    | Capacidade do Replay Buffer     | `100.000` |
| Batch     | Tamanho do mini-batch           | `128`     |

---

## 3. Novas Contribuições Técnicas (Seção IV do Novo Artigo)

O novo artigo pode listar estas contribuições adicionais que diferenciam o trabalho:

1. **Percepção via LiDAR Simulado**: 5 raios frontais com raycasting, permitindo navegação reativa a obstáculos não-mapeados
2. **Espaço de Ações com Proporção Áurea**: Discretização não-linear baseada em `φ ≈ 1.618`, proporcionando controle mais fino em baixas velocidades
3. **Frame Stacking Temporal**: Concatenação de 3 estados consecutivos (48 dimensões), conferindo percepção de velocidade/aceleração relativa
4. **Prioritized Experience Replay**: Árvore de soma hierárquica para priorizar transições com alto erro TD
5. **Filtro Anti-Ressonância**: Penalização explícita de oscilações bruscas no comando angular (`|Δω| > 1.0 → penalty = -3.0 × |Δω|`)
6. **Teste de Generalização com Geometria Procedural**: Validação em ambientes com paredes e portas aleatórias, eliminando overfitting de coordenadas

---

## 4. Estrutura Sugerida para o Novo Manuscrito (Formato SBC)

```
Resumo (PT-BR)
Abstract (EN)

1. Introdução
   - Contextualização de MRS e formação líder-seguidor
   - Limitações de APF e MPC para navegação autônoma
   - Contribuições do trabalho (listar as 6 contribuições técnicas da Seção 3)
   - Corrigir terminologia: remover "slave node", "robust classical control"

2. Trabalhos Relacionados
   - Formação líder-seguidor clássica (Oh et al., Desai et al.)
   - DRL para navegação (Mnih et al., Tai et al., Zhu & Zhang)
   - Extensões DQN: Dueling (Wang et al., 2016), PER (Schaul et al., 2016)
   - Frame Stacking (Mnih et al., 2015)
   - Diferencial: nenhum trabalho anterior combinou PER + Frame Stacking
     + LiDAR simulado + Proporção Áurea para formação líder-seguidor

3. Metodologia
   3.1 Modelo Cinemático (unicycle, manter eq. 1-2)
   3.2 Formulação MDP (corrigir: definir TODOS os símbolos antes de usar)
   3.3 Arquitetura Dueling DQN (detalhar Value/Advantage streams)
   3.4 Percepção LiDAR Simulada (5 raios, raycasting, normalização)
   3.5 Espaço de Ações com Proporção Áurea (φ ≈ 1.618)
   3.6 Frame Stacking Temporal (3 frames × 16 features = 48 obs)
   3.7 Prioritized Experience Replay (SumTree, α, β)
   3.8 Soft Updates (Polyak Averaging, τ = 0.005)
   3.9 Filtro Anti-Ressonância (penalização de |Δω| > 1.0)
   3.10 Controlador Proporcional do Seguidor (manter eq. 15-16)
   - IMPORTANTE: NÃO afirmar "trained independently"
     → usar "single-agent formulation with implicit follower awareness"

4. Experimentos e Resultados
   4.1 Ambiente de Simulação (Sala 8×8 m², paredes, gap, porta)
   4.2 Parâmetros de Treinamento (Tabela I COMPLETA e CONSISTENTE)
   4.3 Cenários de Avaliação (Easy/Medium/Hard com justificativa geométrica)
   4.4 Análise de Trajetórias (Figuras com escala equalizada via CSV)
   4.5 Resultados Quantitativos (Tabela de Sucesso: 500 ep × 4 cenários)
   4.6 Teste de Generalização (Geometria Procedural Dinâmica — test.py)
   4.7 Curva de Aprendizado (training_progress_live.png)

5. Conclusão
   - Resumo das contribuições
   - Resultados principais (taxa de sucesso por cenário)
   - Limitações (ambiente 2D, sem ruído de sensor, sem comunicação real)
   - Trabalhos futuros (múltiplos seguidores, sim-to-real, ROS 2 físico)

Referências (formato SBC)
```

---

## 5. Checklist de Verificação (Antes de Enviar)

- [ ] Todos os parâmetros numéricos no texto batem com o código fonte
- [ ] Figuras com `set_aspect("equal")` e geometria extraída do CSV
- [ ] Termo "slave node" removido de todo o manuscrito
- [ ] Termo "obstacle-rich" substituído por "constrained indoor environment"
- [ ] Palavra "independently" removida ou qualificada na Seção V.E
- [ ] Todos os símbolos definidos na Tabela I antes de serem usados
- [ ] Figura 2 redesenhada sem typos ("actio" → "action")
- [ ] Resultados quantitativos de 500 episódios incluídos para cada cenário
- [ ] Teste de generalização com geometria procedural documentado
