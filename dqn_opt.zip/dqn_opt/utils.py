import os
import csv
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.animation import FuncAnimation
import torch

def plot_episode(filepath, out_dir=None):
    df = pd.read_csv(filepath)
    df = df[df["leader_x"].notna()]

    if out_dir is None:
        out_dir = os.path.dirname(filepath)
    os.makedirs(out_dir, exist_ok=True)

    base = os.path.splitext(os.path.basename(filepath))[0]

    # === POSIÇÃO ===
    plt.figure(figsize=(8, 8))
    plt.plot(df["leader_x"], df["leader_y"], label="Leader", linewidth=3.0)
    plt.plot(df["follower_x"], df["follower_y"], label="Follower", linewidth=3.0)
    
    # --- Desenho da Sala e Obstáculos (Geometria do Log) ---
    # Pegamos a geometria do primeiro frame do log
    inner_wall_y = df["inner_wall_y"].iloc[0]
    inner_wall_xmax = df["inner_wall_xmax"].iloc[0]
    gap_xmax = df["gap_xmax"].iloc[0]
    door_ymin = df["door_ymin"].iloc[0]
    door_ymax = df["door_ymax"].iloc[0]

    # Paredes Externas
    plt.plot([0, 8, 8], [0, 0, door_ymin], 'k', lw=4) # Inferior + canto
    plt.plot([8, 8, 0, 0, 0], [door_ymax, 8, 8, 0, 0], 'k', lw=4) # Restante
    
    # Parede Interna (Horizontal com Gap)
    plt.plot([0, inner_wall_xmax], [inner_wall_y, inner_wall_y], 'k', lw=4)
    plt.plot([gap_xmax, 8], [inner_wall_y, inner_wall_y], 'k', lw=4)
    
    # Porta (Destaque)
    plt.plot([8, 8], [door_ymin, door_ymax], 'orange', lw=6, label='Door')
    
    # Goal
    goal_x, goal_y = df["goal_x"].iloc[0], df["goal_y"].iloc[0]
    plt.scatter(goal_x, goal_y, marker='*', s=200, color='gold', edgecolors='k', zorder=5, label='Goal')
    
    plt.xlabel("X (m)")
    plt.ylabel("Y (m)")
    plt.title("Trajetória na Sala 8x8")
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.gca().set_aspect("equal")

    # Desenha os robôs como círculos na posição final
    leader_pos = (df["leader_x"].iloc[-1], df["leader_y"].iloc[-1])
    follower_pos = (df["follower_x"].iloc[-1], df["follower_y"].iloc[-1])
    
    # Raio: collision_dist/2 = 0.5/2 = 0.25
    c_leader = patches.Circle(leader_pos, 0.25, color='blue', alpha=0.3, label='Leader Body')
    c_follower = patches.Circle(follower_pos, 0.25, color='red', alpha=0.3, label='Follower Body')
    plt.gca().add_patch(c_leader)
    plt.gca().add_patch(c_follower)

    plt.savefig(os.path.join(out_dir, f"{base}_pose.png"), dpi=200, bbox_inches="tight")
    plt.close()

    # === VELOCIDADES ===
    plt.figure(figsize=(10, 6))
    plt.plot(df.index, df["v_leader"], label="Leader v")
    plt.plot(df.index, df["w_leader"], label="Leader w")
    plt.plot(df.index, df["v_follower"], label="Follower v")
    plt.plot(df.index, df["w_follower"], label="Follower w")
    plt.xlabel("Step")
    plt.ylabel("Velocidade")
    plt.title("Velocidades vs Tempo")
    plt.legend()
    plt.grid(True)
    plt.savefig(os.path.join(out_dir, f"{base}_vel.png"), dpi=200, bbox_inches="tight")
    plt.close()

    print(f"[OK] Gráficos salvos para {base}")

def animate_episode(filepath, out_dir=None, fps=20):
    df = pd.read_csv(filepath)
    df = df[df["leader_x"].notna()]
    
    if out_dir is None:
        out_dir = os.path.dirname(filepath)
    os.makedirs(out_dir, exist_ok=True)
    
    base = os.path.splitext(os.path.basename(filepath))[0]
    
    fig, ax = plt.subplots(figsize=(8, 8))
    ax.set_aspect("equal")
    ax.set_xlim(-1, 11)
    ax.set_ylim(-1, 9)
    ax.grid(True, alpha=0.3)
    
    # Derivar cenário salvo do frame 0
    w_y = df["inner_wall_y"].iloc[0] if "inner_wall_y" in df.columns else 4.0
    w_xm = df["inner_wall_xmax"].iloc[0] if "inner_wall_xmax" in df.columns else 6.0
    g_xm = df["gap_xmax"].iloc[0] if "gap_xmax" in df.columns else 8.0
    d_ym = df["door_ymin"].iloc[0] if "door_ymin" in df.columns else 0.5
    d_yx = df["door_ymax"].iloc[0] if "door_ymax" in df.columns else 1.5

    # Desenha Sala 8x8 Dinâmica
    ax.plot([0, 8], [0, 0], "k-", lw=6) # Baixo
    ax.plot([0, 8], [8, 8], "k-", lw=6) # Topo
    ax.plot([0, 0], [0, 8], "k-", lw=6) # Esquerda
    
    ax.plot([8, 8], [0, d_ym], "k-", lw=6) # Parede Dir Inferior
    ax.plot([8, 8], [d_yx, 8], "k-", lw=6) # Parede Dir Superior
    ax.plot([8, 8], [d_ym, d_yx], "g-", lw=8, alpha=0.3) # Porta
    
    ax.plot([0, w_xm], [w_y, w_y], "k-", lw=6) # Parede Interna Inicio
    ax.plot([g_xm, 8], [w_y, w_y], "k-", lw=6) # Parede Interna Fim
    
    leader_plot, = ax.plot([], [], "bo", markersize=18, label="Leader")
    follower_plot, = ax.plot([], [], "ro", markersize=18, label="Follower")
    goal_marker, = ax.plot([], [], "g*", markersize=15, label="Goal")
    
    leader_trail, = ax.plot([], [], "b-", alpha=0.3, lw=2.5)
    follower_trail, = ax.plot([], [], "r-", alpha=0.3, lw=2.5)
    time_text = ax.text(0.05, 0.95, "", transform=ax.transAxes)
    
    def init():
        leader_plot.set_data([], [])
        follower_plot.set_data([], [])
        gx, gy = df["goal_x"].iloc[0], df["goal_y"].iloc[0]
        goal_marker.set_data([gx], [gy])
        leader_trail.set_data([], [])
        follower_trail.set_data([], [])
        time_text.set_text("")
        return leader_plot, follower_plot, goal_marker, leader_trail, follower_trail, time_text

    def update(frame):
        row = df.iloc[frame]
        leader_plot.set_data([row["leader_x"]], [row["leader_y"]])
        follower_plot.set_data([row["follower_x"]], [row["follower_y"]])
        leader_trail.set_data(df["leader_x"][:frame], df["leader_y"][:frame])
        follower_trail.set_data(df["follower_x"][:frame], df["follower_y"][:frame])
        time_text.set_text(f"Step: {frame}")
        return leader_plot, follower_plot, leader_trail, follower_trail, time_text

    ani = FuncAnimation(fig, update, frames=len(df), init_func=init, blit=True)
    save_path = os.path.join(out_dir, f"{base}_animation.gif")
    ani.save(save_path, writer="pillow", fps=fps)
    plt.close()
    print(f"[OK] Animação salva em {save_path}")

def run_episode_collect(agent, set_start_fn, episode_id="test", out_dir="logs"):
    os.makedirs(out_dir, exist_ok=True)
    filepath = os.path.join(out_dir, f"episode_{episode_id}.csv")

    env = agent.env
    env.reset()
    set_start_fn(env)
    
    # Preenche o Frame Stacking do ambiente forçado pelo cenário
    initial_state = env._state()
    for _ in range(env.stack_size):
        env.frame_stack.append(initial_state)
    env.last_dist_target = initial_state[2]
    
    st = env._get_stacked_state()

    with open(filepath, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "t", "leader_x", "leader_y", "leader_th", "v_leader", "w_leader",
            "follower_x", "follower_y", "follower_th", "v_follower", "w_follower",
            "goal_x", "goal_y", "reward", "reason",
            "inner_wall_y", "inner_wall_xmax", "gap_xmax", "door_ymin", "door_ymax"
        ])

        done = False
        steps = 0
        t = 0.0
        while not done and steps < 1000:
            a = agent.act(st, greedy=True)
            st, r, done, info = env.step(a)

            t += env.dt * env.sub
            steps += 1
            l = env.leader
            f0 = env.follower
            g = env.goal
            reason = info.get("reason", "")

            writer.writerow([
                t, l[0], l[1], l[2], env.v_leader, env.w_leader,
                f0[0], f0[1], f0[2], env.v_follower, env.w_follower,
                g[0], g[1], r, reason if done else "",
                env.inner_wall_y, env.inner_wall_xmax, env.gap_xmax, env.door_ymin, env.door_ymax
            ])
    return filepath

def evaluate_difficulty(agent, set_start_fn, name, n_episodes=500):
    successes = 0
    reasons = {}
    total_time = 0.0
    total_final_dist = 0.0
    total_progress = 0.0

    for _ in range(n_episodes):
        env = agent.env
        env.reset()
        set_start_fn(env)
        
        # Preenche o Frame Stacking do ambiente forçado pelo cenário
        initial_state = env._state()
        initial_dist = initial_state[2]
        for _ in range(env.stack_size):
            env.frame_stack.append(initial_state)
        env.last_dist_target = initial_state[2]
        
        st = env._get_stacked_state()

        done = False
        steps = 0
        info = {}
        while not done and steps < 600:
            a = agent.act(st, greedy=True)
            st, r, done, info = env.step(a)
            steps += 1

        reason = info.get("reason", "timeout")
        reasons[reason] = reasons.get(reason, 0) + 1
        
        if reason == "passed_goal":
            successes += 1
            # st[2] is distance to goal (last frame)
            # The state is stacked, so for simplicity we recalculate from leader/goal
            lx, ly = env.leader[0], env.leader[1]
            gx, gy = env.goal[0], env.goal[1]
            final_dist = np.hypot(gx - lx, gy - ly)
            
            total_time += steps * env.dt * env.sub
            total_final_dist += final_dist
            total_progress += (initial_dist - final_dist)

    print(f"\n==============================\nDificuldade: {name.upper()}")
    print(f"Sucessos: {successes}/{n_episodes}\nTaxa de sucesso: {successes/n_episodes:.2f}")
    if successes > 0:
        print(f"Métricas (apenas sucessos):")
        print(f"  Tempo médio: {total_time/successes:.2f} s")
        print(f"  Distância Final média: {total_final_dist/successes:.3f} m")
        print(f"  Progresso médio: {total_progress/successes:.2f} m")
    print("Motivos de término:")
    for k, v in reasons.items(): print(f"  {k}: {v}")
    print("==============================\n")
    
    
    return {"passed_goal": successes, "reasons": reasons}

# --- CENÁRIOS ---
def _set_eval_geometry(env):
    """Configura geometria padrão para avaliação: gap 2m, porta 1m."""
    env.domain_rand = False
    env.inner_wall_y = 4.0
    env.inner_wall_xmax = 6.0
    env.gap_xmin = 6.0
    env.gap_xmax = 8.0
    env.door_ymin = 0.5
    env.door_ymax = 1.5

def set_start_easy(env):
    """Cenario facil: lider ja passou pela brecha (gap), indo para a porta."""
    _set_eval_geometry(env)
    env.reset()
    env.leader = np.array([7.0, 1.0, 0.0])
    env.follower = np.array([6.1, 1.0, 0.0])
    env.passed_breach = True
    env.passed_door = False

def set_start_medium(env):
    """Cenario medio: lider na parte de cima, apontando para o gap."""
    _set_eval_geometry(env)
    env.reset()
    env.leader = np.array([2.5, 6.0, -0.5])
    env.follower = np.array([1.7, 6.4, -0.5])
    env.passed_breach = False
    env.passed_door = False

def set_start_hard(env):
    """Cenario dificil: lider muito perto da parede do meio."""
    _set_eval_geometry(env)
    env.reset()
    env.leader = np.array([3.0, 4.3, 0.0])
    env.follower = np.array([2.1, 4.3, 0.0])
    env.passed_breach = False
    env.passed_door = False

class EvalAgent:
    def __init__(self, policy, env, device):
        self.policy = policy
        self.env = env
        self.device = device

    def act(self, state, greedy=True):
        with torch.no_grad():
            s = torch.from_numpy(state).float().unsqueeze(0).to(self.device)
            q = self.policy(s)
            return int(q.argmax())
