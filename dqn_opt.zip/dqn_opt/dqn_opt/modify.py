import os, re

tex_file = r'c:\dqn\dqn_opt\dqn_opt\artigo\Template_SBC\template-latex\sbc-template.tex'
txt_file = r'c:\dqn\dqn_opt\dqn_opt\artigo_texto.txt'

with open(tex_file, 'r', encoding='utf-8') as f:
    t = f.read()

# Abstract and Intro string replacements
t = t.replace('obstacle-rich', 'constrained indoor')
t = t.replace('1.0 m passage while maintaining 0.3 m formation distance', '1.0 m passage and a 2.0 m gap while maintaining 0.90 m formation distance')
t = t.replace('Deep Q-Network (DQN)', 'Dueling Deep Q-Network (DDQN)')
t = t.replace('slave node', 'follower subsystem')
t = t.replace('robust classical control', 'proportional tracking controller')
t = t.replace('adaptive obstacle avoidance', 'learned obstacle avoidance policy')

# State Space Replacement
old_state_match = re.search(r'\\begin\{align\}\n\s*s_t =.*?\\end\{align\}', t, re.DOTALL)
if old_state_match:
    new_state = r'''\begin{align}
    o_t = [e_x, e_y, d_{goal}, d_{pair}, \sin(\theta_L), \cos(\theta_L), \nonumber \\
    \sin(\theta_F), \cos(\theta_F), \psi_{head}, I_{breach}, I_{door}, l_1, l_2, l_3, l_4, l_5]^T
    \label{eq:state}
\end{align}
where $e_x, e_y$ are positional errors to the current waypoint, $d_{goal}$ is the distance to the goal, $d_{pair}$ is the inter-robot distance, $I_{breach}$ and $I_{door}$ are binary checkpoint indicators, and $l_1, \dots, l_5$ are normalized simulated LiDAR readings at angles $\{-60^\circ, -30^\circ, 0^\circ, 30^\circ, 60^\circ\}$.
To provide velocity and acceleration context, we employ Frame Stacking, concatenating the $3$ most recent frames to form the final 48-dimensional state vector $s_t = [o_t, o_{t-1}, o_{t-2}]^T$.'''
    t = t.replace(old_state_match.group(0), new_state)

t = re.sub(r'where \$L_\{goal_x\}.*?the relative heading.', '', t, flags=re.DOTALL)

# Action Space Replacement
old_action = r'''The action space was made very small, with K = 3, where:
\begin{equation}
    \mathcal{A_v} = \{0.00, 0.25, 0.50\},
\end{equation}
\begin{equation}
    \mathcal{A_{\omega}} = \{-0.7, 0.0, 0.7\}
\end{equation}'''
new_action = r'''We discretize the velocity space using 5 linear and 8 angular velocities derived from the Golden Ratio ($\phi \approx 1.618$), providing fine control at low speeds and coarser control at high speeds, resulting in $|\mathcal{A}| = 40$ discrete actions.'''
t = t.replace(old_action, new_action)

old_action2 = r'''DQN requires discrete actions. We discretize the velocity space into $K$ predefined values:
\begin{equation}
    \mathcal{A} = \{ (v_k, \omega_k) \mid k = 1, \ldots, K \}
    \label{eq:actions}
\end{equation}
These include forward motion, combined translation-rotation, and pure rotation, enabling maneuverability in confined spaces.'''
new_action2 = r'''DDQN requires discrete actions. We discretize the velocity space into $K=40$ predefined values utilizing 5 linear and 8 angular velocities derived from the Golden Ratio ($\phi \approx 1.618$).'''
t = t.replace(old_action2, new_action2)

# Network Architecture Replacement
old_net = re.search(r'The action-value function.*?computationally constrained robotic platforms\.', t, re.DOTALL)
if old_net:
    new_net = r'''The action-value function is approximated by a Dueling Deep Q-Network (DDQN) \cite{wang2016dueling} architecture parameterized by $\theta$. The input layer accepts the 48-dimensional stacked state vector, which passes through a feature extractor comprised of two hidden layers (64 neurons each) with ReLU activation. The network then bifurcates into a Value stream (one hidden layer of 32 neurons) and an Advantage stream (one hidden layer of 32 neurons). These streams aggregate to output the Q-values for the 40 discrete actions. This architecture has approximately 7,500 parameters, ensuring inference efficiency while resolving the issue of shallow networks.'''
    t = t.replace(old_net.group(0), new_net)


# Table 1 Replacement
old_table = re.search(r'\\begin\{table\}\[h\].*?\\end\{table\}', t, re.DOTALL)
if old_table:
    new_table = r'''\begin{table}[h]
\centering
\caption{Training and Simulation Parameters}
\label{tab:params}
\begin{tabular}{l l c}
\hline
\textbf{Symbol} & \textbf{Parameter} & \textbf{Value} \\
\hline
$\gamma$ & Discount factor & 0.99 \\
$\alpha$ & Learning rate (Adam) & $1\times10^{-3}$ \\
$\tau$ & Soft update rate (Polyak) & 0.005 \\
Cap & Replay buffer capacity & 100,000 \\
Batch & Mini-batch size & 128 \\
$\alpha_{PER}$ & PER prioritization exponent & 0.6 \\
$\beta_{start}$ & PER bias correction & 0.4 \\
$\epsilon_{start}$ & Initial exploration & 1.0 \\
$\epsilon_{decay}$ & Exploration decay & 0.9999 \\
$\epsilon_{\min}$ & Minimum exploration & 0.05 \\
$d_{des}$ & Formation distance $d_{gap}$ & 0.90 m \\
$(k_d, k_\omega)$ & Follower gains & (0.8, 1.4) \\
\hline
\end{tabular}
\end{table}'''
    t = t.replace(old_table.group(0), new_table)

# Evaluation Scenarios Replacement
old_eval = re.search(r'To assess the generalization capability.*?Hard:.*?wall edge\.', t, re.DOTALL)
if old_eval:
    new_eval = r'''To assess the generalization capability of the learned policy, we evaluated the system under an $8 \times 8$ m constrained indoor environment featuring an inner wall with a 2.0 m gap and an outer wall with a 1.0 m door. We validate using three specific initial configurations and a procedural generalization test:

\begin{itemize}
    \item \textbf{Easy:} The leader starts at $(7.0, 1.0)$, situated in the lower half near the exit door, requiring primarily alignment and egress maneuvers.
    \item \textbf{Medium:} The leader starts at $(2.5, 6.0)$, pointing obliquely towards the gap in the upper area, requiring a trajectory that safely circles the inner wall.
    \item \textbf{Hard:} The leader starts at $(3.0, 4.8)$, positioned extremely close to the inner wall, demanding severe maneuvering to avoid immediate collision.
    \item \textbf{Generalization:} 500 episodes with randomly generated obstacle positions (procedural variation of the gap width $1.5{-}2.5$ m and lateral shifting of the wall and door) to test policy robustness.
\end{itemize}

\subsection{Quantitative Results}
A quantitative evaluation over 500 episodes per scenario was conducted. Table \ref{tab:results} summarizes the success rates alongside collision and timeout occurrences, proving the reliability of the system under high geometrical stress.

\begin{table}[h]
\centering
\caption{Quantitative Performance (500 episodes per scenario)}
\label{tab:results}
\begin{tabular}{l c c c}
\hline
\textbf{Scenario} & \textbf{Success (\%)} & \textbf{Collision (\%)} & \textbf{Timeout (\%)} \\
\hline
Easy & a medir & a medir & a medir \\
Medium & a medir & a medir & a medir \\
Hard & a medir & a medir & a medir \\
Generalization & a medir & a medir & a medir \\
\hline
\end{tabular}
\end{table}'''
    t = t.replace(old_eval.group(0), new_eval)

# Additional tweaks
t = t.replace(r'0.8\,m passage', r'1.0\,m door and 2.0\,m gap')
t = t.replace(r'0.5\,m formation distance', r'0.90\,m formation distance')
t = t.replace(r'0.3\,m distance', r'0.90\,m distance')
t = t.replace(r'0.3 m formation distance', r'0.90 m formation distance')
t = t.replace(r'k_{dist}=1', r'k_{d}=0.8')
t = t.replace(r'trained independently (single-agent RL)', r'evaluated utilizing a single-agent formulation with implicit follower awareness')
t = t.replace(r'single-agent training process', r'single-agent formulation with implicit follower awareness')
t = t.replace(r'single-agent RL', r'single-agent formulation')
t = t.replace(r'singleagent system', r'single-agent formulation')
t = t.replace(r'(-2, 0)', r'(7.0, 1.0)')
t = t.replace(r'(-2, -0.8)', r'(2.5, 6.0)')
t = t.replace(r'(-2, -1.2)', r'(3.0, 4.8)')

with open(tex_file, 'w', encoding='utf-8') as f:
    f.write(t)

with open(txt_file, 'w', encoding='utf-8') as f:
    f.write(t)

print('Done')
