import torch
import os
from env import LeaderFollowerEnv
from model import DuelingDQN
from utils import EvalAgent, evaluate_difficulty, set_start_easy, set_start_medium, set_start_hard

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
MODEL_PATH = "best_model.pth"  # Usa o melhor modelo salvo durante o treino

def run_eval():
    # Fallback para model.pth se best_model.pth não existir
    path = MODEL_PATH if os.path.exists(MODEL_PATH) else "model.pth"
    if not os.path.exists(path):
        print(f"[ERRO] Nenhum arquivo de pesos encontrado.")
        return

    env = LeaderFollowerEnv()
    obs_dim = len(env.reset())
    policy = DuelingDQN(obs_dim, env.na).to(DEVICE)
    policy.load_state_dict(torch.load(path, map_location=DEVICE, weights_only=True))
    policy.eval()

    agent = EvalAgent(policy, env, DEVICE)
    
    scenarios = [
        ("easy", set_start_easy),
        ("medium", set_start_medium),
        ("hard", set_start_hard),
    ]
    
    for name, start_fn in scenarios:
        evaluate_difficulty(agent, start_fn, name, n_episodes=500)

if __name__ == "__main__":
    run_eval()
