"""
Gerador de figuras para o artigo.
Gera TODAS as figuras necessárias no diretório artigo/Template_SBC/template-latex/
"""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Arc, Circle
import numpy as np
import os

OUT = r"artigo\Template_SBC\template-latex"
os.makedirs(OUT, exist_ok=True)

# Cores consistentes
C_LEADER = '#2563EB'   # Azul
C_FOLLOWER = '#DC2626' # Vermelho
C_WALL = '#1F2937'     # Cinza escuro
C_GAP = '#10B981'      # Verde
C_DOOR = '#F59E0B'     # Amarelo/Laranja
C_GOAL = '#10B981'     # Verde
C_TRAJ = '#8B5CF6'     # Roxo
C_BG = '#FAFAFA'       # Fundo

def set_style():
    plt.rcParams.update({
        'font.family': 'serif',
        'font.size': 11,
        'axes.labelsize': 12,
        'axes.titlesize': 13,
        'figure.facecolor': 'white',
        'savefig.dpi': 300,
        'savefig.bbox': 'tight',
        'savefig.pad_inches': 0.1,
    })

# ==========================================================
# FIGURA 1: Geometria da Formação Leader-Follower
# ==========================================================
def fig_formation_geometry():
    set_style()
    fig, ax = plt.subplots(1, 1, figsize=(7, 4.5))
    ax.set_xlim(-1, 8)
    ax.set_ylim(-1.5, 3.5)
    ax.set_aspect('equal')
    ax.axis('off')

    # Robô Líder
    lx, ly, lth = 5.0, 1.5, np.radians(30)
    leader = Circle((lx, ly), 0.3, color=C_LEADER, alpha=0.9, zorder=5)
    ax.add_patch(leader)
    ax.annotate('Leader ($L$)', (lx, ly + 0.6), fontsize=11, ha='center',
                fontweight='bold', color=C_LEADER)
    # Seta de heading
    ax.annotate('', xy=(lx + 0.8*np.cos(lth), ly + 0.8*np.sin(lth)),
                xytext=(lx, ly),
                arrowprops=dict(arrowstyle='->', color=C_LEADER, lw=2))
    ax.text(lx + 1.0*np.cos(lth), ly + 1.0*np.sin(lth), r'$\theta_L$',
            fontsize=11, color=C_LEADER)

    # Ponto virtual P_des (atrás do líder)
    d_des = 2.5
    px = lx - d_des * np.cos(lth)
    py = ly - d_des * np.sin(lth)
    ax.plot(px, py, 'x', color=C_GOAL, markersize=12, markeredgewidth=3, zorder=5)
    ax.annotate(r'$P_{des}$', (px - 0.1, py + 0.45), fontsize=12, ha='center',
                color=C_GOAL, fontweight='bold')

    # Linha d_des
    ax.annotate('', xy=(px, py), xytext=(lx, ly),
                arrowprops=dict(arrowstyle='<->', color='#6B7280', lw=1.5,
                                connectionstyle='arc3,rad=0'))
    mid_x = (lx + px) / 2
    mid_y = (ly + py) / 2
    ax.text(mid_x + 0.15, mid_y + 0.4, r'$d_{des}$', fontsize=12,
            color='#6B7280', ha='center')

    # Robô Seguidor (com erro)
    fx, fy = px + 0.5, py - 0.4
    follower = Circle((fx, fy), 0.3, color=C_FOLLOWER, alpha=0.9, zorder=5)
    ax.add_patch(follower)
    ax.annotate('Follower ($F$)', (fx, fy - 0.6), fontsize=11, ha='center',
                fontweight='bold', color=C_FOLLOWER)
    fth = np.radians(45)
    ax.annotate('', xy=(fx + 0.7*np.cos(fth), fy + 0.7*np.sin(fth)),
                xytext=(fx, fy),
                arrowprops=dict(arrowstyle='->', color=C_FOLLOWER, lw=2))
    ax.text(fx + 0.9*np.cos(fth), fy + 0.9*np.sin(fth), r'$\theta_F$',
            fontsize=11, color=C_FOLLOWER)

    # Vetor de erro e
    ax.annotate('', xy=(px, py), xytext=(fx, fy),
                arrowprops=dict(arrowstyle='->', color='#EF4444', lw=2,
                                linestyle='dashed'))
    ax.text((fx + px)/2 - 0.5, (fy + py)/2, r'$\mathbf{e}$', fontsize=13,
            color='#EF4444', fontweight='bold')

    # Goal
    gx, gy = 7.0, 2.5
    ax.plot(gx, gy, '*', color=C_GOAL, markersize=20, zorder=5)
    ax.text(gx + 0.3, gy, 'Goal', fontsize=11, color=C_GOAL, fontweight='bold')

    # Eixos de referência
    ax.annotate('', xy=(0.5, -1), xytext=(0, -1),
                arrowprops=dict(arrowstyle='->', color='black', lw=1.5))
    ax.annotate('', xy=(0, -0.5), xytext=(0, -1),
                arrowprops=dict(arrowstyle='->', color='black', lw=1.5))
    ax.text(0.6, -1.1, '$X$', fontsize=10)
    ax.text(-0.2, -0.4, '$Y$', fontsize=10)

    fig.savefig(os.path.join(OUT, 'Figure2_formation.png'))
    plt.close()
    print("[OK] Figure2_formation.png")

# ==========================================================
# FIGURA 2: Diagrama do Treinamento DQN
# ==========================================================
def fig_training_diagram():
    set_style()
    fig, ax = plt.subplots(1, 1, figsize=(8, 3.5))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4)
    ax.axis('off')

    box_style = dict(boxstyle='round,pad=0.4', facecolor='#EBF5FB',
                     edgecolor='#2563EB', linewidth=1.5)
    box_style2 = dict(boxstyle='round,pad=0.4', facecolor='#FEF3C7',
                      edgecolor='#D97706', linewidth=1.5)
    box_style3 = dict(boxstyle='round,pad=0.4', facecolor='#ECFDF5',
                      edgecolor='#059669', linewidth=1.5)

    # Agent
    ax.text(1.2, 3.0, 'DQN Agent\n(Dueling DDQN)', fontsize=10, ha='center',
            va='center', bbox=box_style, fontweight='bold')

    # Environment
    ax.text(5.0, 3.0, 'Environment\n(8×8m Room)', fontsize=10, ha='center',
            va='center', bbox=box_style3, fontweight='bold')

    # Replay Buffer
    ax.text(8.5, 3.0, 'PER Buffer\n(100k)', fontsize=10, ha='center',
            va='center', bbox=box_style2, fontweight='bold')

    # Target Network
    ax.text(1.2, 0.8, 'Target Network\n' + r'$\theta^-$', fontsize=10,
            ha='center', va='center', bbox=box_style, fontweight='bold')

    # Arrows: Agent -> Env (action)
    ax.annotate('', xy=(3.5, 3.3), xytext=(2.4, 3.3),
                arrowprops=dict(arrowstyle='->', color=C_LEADER, lw=2))
    ax.text(2.95, 3.55, r'$a_t$', fontsize=11, ha='center', color=C_LEADER)

    # Env -> Agent (state, reward)
    ax.annotate('', xy=(2.4, 2.7), xytext=(3.5, 2.7),
                arrowprops=dict(arrowstyle='->', color=C_GOAL, lw=2))
    ax.text(2.95, 2.35, r'$s_t, r_t$', fontsize=11, ha='center', color=C_GOAL)

    # Env -> Buffer (transition)
    ax.annotate('', xy=(7.0, 3.0), xytext=(6.5, 3.0),
                arrowprops=dict(arrowstyle='->', color='#D97706', lw=2))
    ax.text(6.75, 3.35, r'$(s,a,r,s\')$', fontsize=9, ha='center', color='#D97706')

    # Buffer -> Agent (sample)
    ax.annotate('', xy=(2.4, 2.2), xytext=(7.5, 1.5),
                arrowprops=dict(arrowstyle='->', color='#D97706', lw=1.5,
                                connectionstyle='arc3,rad=-0.2'))
    ax.text(5.0, 1.2, 'Sample\nBatch', fontsize=9, ha='center', color='#D97706')

    # Agent -> Target (soft update)
    ax.annotate('', xy=(1.2, 1.5), xytext=(1.2, 2.3),
                arrowprops=dict(arrowstyle='->', color='#6B7280', lw=1.5,
                                linestyle='dashed'))
    ax.text(0.2, 1.9, r'$\tau$-update', fontsize=9, color='#6B7280')

    fig.savefig(os.path.join(OUT, 'Figure3_training.png'))
    plt.close()
    print("[OK] Figure3_training.png")

# ==========================================================
# FIGURA 3: Arquitetura do Sistema
# ==========================================================
def fig_system_architecture():
    set_style()
    fig, ax = plt.subplots(1, 1, figsize=(9, 4))
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 5)
    ax.axis('off')

    # Estilos
    leader_box = dict(boxstyle='round,pad=0.5', facecolor='#DBEAFE',
                      edgecolor=C_LEADER, linewidth=2)
    follower_box = dict(boxstyle='round,pad=0.5', facecolor='#FEE2E2',
                        edgecolor=C_FOLLOWER, linewidth=2)
    sensor_box = dict(boxstyle='round,pad=0.3', facecolor='#F3F4F6',
                      edgecolor='#6B7280', linewidth=1.5)
    comm_box = dict(boxstyle='round,pad=0.3', facecolor='#FEF3C7',
                    edgecolor='#D97706', linewidth=1.5)

    # --- LEADER SUBSYSTEM ---
    ax.text(1.2, 4.3, 'LEADER SUBSYSTEM', fontsize=10, fontweight='bold',
            color=C_LEADER)

    ax.text(1.2, 3.3, 'LiDAR\nSensor\n(5 rays)', fontsize=9, ha='center',
            va='center', bbox=sensor_box)

    ax.text(3.8, 3.3, 'State\nEncoder\n' + r'$s_t$ (60-dim)', fontsize=9,
            ha='center', va='center', bbox=leader_box)

    ax.text(6.0, 3.3, 'Dueling\nDDQN\n(218k params)', fontsize=9,
            ha='center', va='center', bbox=leader_box, fontweight='bold')

    # Arrows leader
    ax.annotate('', xy=(2.8, 3.3), xytext=(2.0, 3.3),
                arrowprops=dict(arrowstyle='->', color=C_LEADER, lw=1.5))
    ax.annotate('', xy=(5.0, 3.3), xytext=(4.8, 3.3),
                arrowprops=dict(arrowstyle='->', color=C_LEADER, lw=1.5))

    # Output do DDQN
    ax.text(7.8, 3.3, r'$(v_L, \omega_L)$', fontsize=11, ha='center',
            va='center', bbox=leader_box)
    ax.annotate('', xy=(7.2, 3.3), xytext=(6.8, 3.3),
                arrowprops=dict(arrowstyle='->', color=C_LEADER, lw=1.5))

    # --- COMMUNICATION ---
    ax.text(5.5, 1.9, 'ROS 2\nTopic', fontsize=9, ha='center',
            va='center', bbox=comm_box)
    ax.annotate(r'$q_L = [x_L, y_L, \theta_L]^T$', xy=(5.5, 1.4),
                fontsize=9, ha='center', color='#D97706')

    ax.annotate('', xy=(5.5, 2.3), xytext=(7.0, 2.8),
                arrowprops=dict(arrowstyle='->', color='#D97706', lw=1.5))

    # --- FOLLOWER SUBSYSTEM ---
    ax.text(1.2, 0.8, 'FOLLOWER SUBSYSTEM', fontsize=10, fontweight='bold',
            color=C_FOLLOWER)

    ax.text(3.8, 0.5, r'Virtual Target ($P_{des}$)' + '\n' + r'$d_{des}$ behind leader',
            fontsize=9, ha='center', va='center', bbox=follower_box)

    ax.text(7.0, 0.5, 'P-Controller\n' + r'$k_d=0.8$  $k_\omega=1.4$',
            fontsize=9, ha='center', va='center', bbox=follower_box, fontweight='bold')

    ax.text(9.5, 0.5, r'$(v_F, \omega_F)$', fontsize=11, ha='center',
            va='center', bbox=follower_box)

    # Arrows follower
    ax.annotate('', xy=(3.0, 0.5), xytext=(5.5, 1.5),
                arrowprops=dict(arrowstyle='->', color='#D97706', lw=1.5))
    ax.annotate('', xy=(6.0, 0.5), xytext=(5.2, 0.5),
                arrowprops=dict(arrowstyle='->', color=C_FOLLOWER, lw=1.5))
    ax.annotate('', xy=(8.8, 0.5), xytext=(8.0, 0.5),
                arrowprops=dict(arrowstyle='->', color=C_FOLLOWER, lw=1.5))

    # Frame delimitador
    rect_l = mpatches.FancyBboxPatch((0.2, 2.3), 8.5, 2.3, boxstyle='round,pad=0.15',
                                      facecolor='none', edgecolor=C_LEADER,
                                      linestyle='--', linewidth=1.5)
    rect_f = mpatches.FancyBboxPatch((0.2, -0.2), 10.3, 1.6, boxstyle='round,pad=0.15',
                                      facecolor='none', edgecolor=C_FOLLOWER,
                                      linestyle='--', linewidth=1.5)
    ax.add_patch(rect_l)
    ax.add_patch(rect_f)

    fig.savefig(os.path.join(OUT, 'Figure4_architecture.png'))
    plt.close()
    print("[OK] Figure4_architecture.png")

# ==========================================================
# FIGURA 4: Cenário de Simulação (8x8m)
# ==========================================================
def fig_simulation_scenario():
    set_style()
    fig, ax = plt.subplots(1, 1, figsize=(6, 6))

    # Sala 8x8
    wall_y = 4.0
    gap_xmin, gap_xmax = 6.0, 8.0
    door_ymin, door_ymax = 0.5, 1.5

    # Paredes externas
    room = plt.Rectangle((0, 0), 8, 8, fill=False, edgecolor=C_WALL, linewidth=3)
    ax.add_patch(room)

    # Parede interna (de 0 a gap_xmin)
    ax.plot([0, gap_xmin], [wall_y, wall_y], color=C_WALL, linewidth=4, solid_capstyle='round')
    ax.text(3.0, wall_y + 0.2, 'Inner Wall', fontsize=10, ha='center', color=C_WALL)

    # Gap (região verde)
    gap_rect = plt.Rectangle((gap_xmin, wall_y - 0.1), gap_xmax - gap_xmin, 0.2,
                              color=C_GAP, alpha=0.3)
    ax.add_patch(gap_rect)
    ax.annotate('', xy=(gap_xmax, wall_y - 0.5), xytext=(gap_xmin, wall_y - 0.5),
                arrowprops=dict(arrowstyle='<->', color=C_GAP, lw=1.5))
    ax.text((gap_xmin + gap_xmax)/2, wall_y - 0.8, '2.0 m gap', fontsize=10,
            ha='center', color=C_GAP, fontweight='bold')

    # Porta na parede direita
    ax.plot([8, 8], [0, door_ymin], color=C_WALL, linewidth=4)
    ax.plot([8, 8], [door_ymax, 8], color=C_WALL, linewidth=4)
    door_rect = plt.Rectangle((7.85, door_ymin), 0.3, door_ymax - door_ymin,
                               color=C_DOOR, alpha=0.3)
    ax.add_patch(door_rect)
    ax.annotate('', xy=(8.5, door_ymax), xytext=(8.5, door_ymin),
                arrowprops=dict(arrowstyle='<->', color=C_DOOR, lw=1.5))
    ax.text(8.8, (door_ymin + door_ymax)/2, '1.0 m\ndoor', fontsize=9,
            ha='left', color=C_DOOR, fontweight='bold')

    # Zona de Spawn (acima da parede)
    spawn = plt.Rectangle((0.5, 5.0), 7.0, 2.0, fill=True,
                           facecolor='#DBEAFE', edgecolor=C_LEADER,
                           linewidth=1, linestyle='--', alpha=0.3)
    ax.add_patch(spawn)
    ax.text(4.0, 6.0, 'Spawn Area', fontsize=10, ha='center',
            color=C_LEADER, style='italic')

    # Posições de teste
    configs = [
        (7.0, 1.0, 'Easy', '#10B981'),
        (2.5, 6.0, 'Medium', '#F59E0B'),
        (3.0, 4.3, 'Hard', '#EF4444'),
    ]
    for x, y, label, color in configs:
        ax.plot(x, y, 'o', color=color, markersize=10, zorder=5)
        ax.text(x + 0.3, y + 0.2, label, fontsize=9, color=color, fontweight='bold')

    # Goal
    ax.plot(10.0, 1.0, '*', color=C_GOAL, markersize=18, zorder=5)
    ax.text(10.0, 0.4, 'Goal', fontsize=10, ha='center', color=C_GOAL, fontweight='bold')

    # Trajetória exemplo (seta curva)
    t = np.linspace(0, 1, 50)
    traj_x = 2.5 + 4.5*t + 1.0*np.sin(np.pi*t)
    traj_y = 6.0 - 2.0*t - 2.5*t**2 + 0.5*np.sin(2*np.pi*t)
    ax.plot(traj_x, traj_y, '--', color=C_TRAJ, alpha=0.4, linewidth=1.5)

    ax.set_xlim(-0.5, 11)
    ax.set_ylim(-0.5, 8.5)
    ax.set_aspect('equal')
    ax.set_xlabel('$x$ (m)', fontsize=12)
    ax.set_ylabel('$y$ (m)', fontsize=12)
    ax.grid(True, alpha=0.2)

    fig.savefig(os.path.join(OUT, 'ultimo_frame.png'))
    plt.close()
    print("[OK] ultimo_frame.png")

# ==========================================================
# FIGURA 5: Curva de Treinamento
# ==========================================================
def fig_training_curve():
    set_style()
    # Copiar do logs se existe
    src = os.path.join('logs', 'training_progress_live.png')
    dst = os.path.join(OUT, 'training_progress.png')
    if os.path.exists(src):
        import shutil
        shutil.copy2(src, dst)
        print(f"[OK] training_progress.png (copiado de logs/)")
    else:
        print("[SKIP] training_progress_live.png não encontrado")

# ==========================================================
# FIGURA 6: Trajetórias Easy/Medium/Hard (combinadas)
# ==========================================================
def fig_trajectories_combined():
    set_style()
    from PIL import Image

    paths = [
        ('logs/easy/episode_easy_pose.png', 'Easy'),
        ('logs/medium/episode_medium_pose.png', 'Medium'),
        ('logs/hard/episode_hard_pose.png', 'Hard'),
    ]

    existing = [(p, l) for p, l in paths if os.path.exists(p)]
    if not existing:
        print("[SKIP] Nenhum arquivo de trajetória encontrado")
        return

    fig, axes = plt.subplots(1, len(existing), figsize=(5*len(existing), 5))
    if len(existing) == 1:
        axes = [axes]

    for ax, (path, label) in zip(axes, existing):
        img = Image.open(path)
        ax.imshow(img)
        ax.set_title(f'{label}', fontsize=14, fontweight='bold')
        ax.axis('off')

    plt.tight_layout()
    fig.savefig(os.path.join(OUT, 'xy_all.png'))
    plt.close()
    print("[OK] xy_all.png")

# ==========================================================
# FIGURA 7: Curriculum Learning
# ==========================================================
def fig_curriculum():
    set_style()
    fig, ax1 = plt.subplots(1, 1, figsize=(7, 3.5))

    episodes = np.linspace(0, 40000, 1000)
    gap_size = np.piecewise(episodes,
        [episodes < 10000,
         (episodes >= 10000) & (episodes < 30000),
         episodes >= 30000],
        [3.0,
         lambda e: 3.0 - (e - 10000) / 20000 * 1.0,
         2.0])

    door_size = np.piecewise(episodes,
        [episodes < 10000,
         (episodes >= 10000) & (episodes < 30000),
         episodes >= 30000],
        [2.0,
         lambda e: 2.0 - (e - 10000) / 20000 * 1.0,
         1.0])

    rand_str = np.piecewise(episodes,
        [episodes < 10000,
         (episodes >= 10000) & (episodes < 30000),
         episodes >= 30000],
        [0.0,
         lambda e: (e - 10000) / 20000,
         1.0])

    ax1.plot(episodes/1000, gap_size, '-', color=C_LEADER, linewidth=2.5, label='Gap Size (m)')
    ax1.plot(episodes/1000, door_size, '-', color=C_FOLLOWER, linewidth=2.5, label='Door Size (m)')
    ax1.set_xlabel('Training Episode (×1000)', fontsize=12)
    ax1.set_ylabel('Size (m)', fontsize=12, color='#374151')
    ax1.tick_params(axis='y', labelcolor='#374151')

    ax2 = ax1.twinx()
    ax2.plot(episodes/1000, rand_str, '--', color=C_GOAL, linewidth=2.5,
             label='Randomization Strength')
    ax2.set_ylabel('Randomization Strength', fontsize=12, color=C_GOAL)
    ax2.tick_params(axis='y', labelcolor=C_GOAL)
    ax2.set_ylim(-0.05, 1.1)

    # Phase annotations
    ax1.axvspan(0, 10, alpha=0.08, color=C_LEADER)
    ax1.axvspan(10, 30, alpha=0.08, color=C_DOOR)
    ax1.axvspan(30, 40, alpha=0.08, color=C_FOLLOWER)
    ax1.text(5, 0.3, 'Phase 1\n(Easy)', fontsize=9, ha='center', style='italic', color='#6B7280')
    ax1.text(20, 0.3, 'Phase 2\n(Transition)', fontsize=9, ha='center', style='italic', color='#6B7280')
    ax1.text(35, 0.3, 'Phase 3\n(Hard)', fontsize=9, ha='center', style='italic', color='#6B7280')

    # Combine legends
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper right', fontsize=9)

    ax1.set_xlim(0, 40)
    ax1.grid(True, alpha=0.2)

    fig.savefig(os.path.join(OUT, 'curriculum_phases.png'))
    plt.close()
    print("[OK] curriculum_phases.png")

# ==========================================================
# FIGURA 8: Exemplos de Generalização
# ==========================================================
def fig_generalization():
    set_style()
    from PIL import Image

    paths = [
        'logs/generalization/episode_random_1_pose.png',
        'logs/generalization/episode_random_2_pose.png',
        'logs/generalization/episode_random_3_pose.png',
    ]

    existing = [p for p in paths if os.path.exists(p)]
    if not existing:
        print("[SKIP] Nenhum arquivo de generalização encontrado")
        return

    fig, axes = plt.subplots(1, len(existing), figsize=(5*len(existing), 5))
    if len(existing) == 1:
        axes = [axes]

    for i, (ax, path) in enumerate(zip(axes, existing)):
        img = Image.open(path)
        ax.imshow(img)
        ax.set_title(f'Random Layout {i+1}', fontsize=13, fontweight='bold')
        ax.axis('off')

    plt.tight_layout()
    fig.savefig(os.path.join(OUT, 'generalization_examples.png'))
    plt.close()
    print("[OK] generalization_examples.png")

# ==========================================================
# FIGURA 9: Rede Neural DDQN (Arquitetura)
# ==========================================================
def fig_network():
    set_style()
    fig, ax = plt.subplots(1, 1, figsize=(9, 3))
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 4)
    ax.axis('off')

    layers = [
        (1.0, 'Input\n60-dim', '#F3F4F6', '#6B7280'),
        (3.0, 'FC 256\n+ LN + ReLU', '#DBEAFE', C_LEADER),
        (5.0, 'FC 256\n+ LN + ReLU', '#DBEAFE', C_LEADER),
        (7.0, 'FC 256\n+ LN + ReLU', '#DBEAFE', C_LEADER),
    ]

    for x, label, fc, ec in layers:
        box = FancyBboxPatch((x-0.6, 1.2), 1.2, 1.6,
                             boxstyle='round,pad=0.1', facecolor=fc,
                             edgecolor=ec, linewidth=1.5)
        ax.add_patch(box)
        ax.text(x, 2.0, label, fontsize=9, ha='center', va='center', fontweight='bold')

    # Split into Value and Advantage
    # Value stream
    vbox = FancyBboxPatch((8.6, 2.4), 1.2, 1.2,
                          boxstyle='round,pad=0.1', facecolor='#ECFDF5',
                          edgecolor=C_GOAL, linewidth=1.5)
    ax.add_patch(vbox)
    ax.text(9.2, 3.0, 'Value\n128→1', fontsize=9, ha='center', va='center',
            fontweight='bold', color=C_GOAL)

    # Advantage stream
    abox = FancyBboxPatch((8.6, 0.4), 1.2, 1.2,
                          boxstyle='round,pad=0.1', facecolor='#FEF3C7',
                          edgecolor='#D97706', linewidth=1.5)
    ax.add_patch(abox)
    ax.text(9.2, 1.0, 'Advantage\n128→40', fontsize=9, ha='center', va='center',
            fontweight='bold', color='#D97706')

    # Output
    obox = FancyBboxPatch((10.5, 1.2), 1.2, 1.6,
                          boxstyle='round,pad=0.1', facecolor='#F3F4F6',
                          edgecolor='#6B7280', linewidth=1.5)
    ax.add_patch(obox)
    ax.text(11.1, 2.0, 'Q-values\n40 actions', fontsize=9, ha='center',
            va='center', fontweight='bold')

    # Arrows
    for i in range(len(layers)-1):
        x1 = layers[i][0] + 0.6
        x2 = layers[i+1][0] - 0.6
        ax.annotate('', xy=(x2, 2.0), xytext=(x1, 2.0),
                    arrowprops=dict(arrowstyle='->', color='#6B7280', lw=1.5))

    # Split arrow
    ax.annotate('', xy=(8.6, 3.0), xytext=(7.6, 2.3),
                arrowprops=dict(arrowstyle='->', color=C_GOAL, lw=1.5))
    ax.annotate('', xy=(8.6, 1.0), xytext=(7.6, 1.7),
                arrowprops=dict(arrowstyle='->', color='#D97706', lw=1.5))

    # Merge arrow
    ax.annotate('', xy=(10.5, 2.3), xytext=(9.8, 3.0),
                arrowprops=dict(arrowstyle='->', color=C_GOAL, lw=1.5))
    ax.annotate('', xy=(10.5, 1.7), xytext=(9.8, 1.0),
                arrowprops=dict(arrowstyle='->', color='#D97706', lw=1.5))

    # Aggregation label
    ax.text(10.3, 2.0, '+', fontsize=14, ha='center', va='center',
            fontweight='bold', color='#6B7280')

    fig.savefig(os.path.join(OUT, 'network_architecture.png'))
    plt.close()
    print("[OK] network_architecture.png")


if __name__ == '__main__':
    print("=== Gerando figuras do artigo ===\n")
    fig_formation_geometry()
    fig_training_diagram()
    fig_system_architecture()
    fig_simulation_scenario()
    fig_training_curve()
    fig_trajectories_combined()
    fig_curriculum()
    fig_generalization()
    fig_network()
    print("\n=== Todas as figuras geradas! ===")
