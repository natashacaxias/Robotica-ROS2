import torch
import numpy as np
import os
from env import LeaderFollowerEnv
from model import DuelingDQN
from utils import EvalAgent, run_episode_collect, plot_episode, animate_episode, evaluate_difficulty

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
MODEL_PATH = "best_model.pth" if os.path.exists("best_model.pth") else "model.pth"

def set_dynamic_geometry(env):
    """
    Generalização: gap=2m e porta=1m (mesmo tamanho do eval),
    mas com posições ALEATÓRIAS para testar generalização.
    """
    # 1. Randomiza posição da Parede Central (y entre 3.5 e 5.0)
    env.inner_wall_y = np.random.uniform(3.5, 5.0)
    
    # 2. Gap FIXO de 2m, posição aleatória ao longo do X
    gap_width = 2.0
    gap_start = np.random.uniform(0.0, 8.0 - gap_width)
    env.inner_wall_xmin = 0.0
    env.inner_wall_xmax = gap_start
    env.gap_xmin = gap_start
    env.gap_xmax = gap_start + gap_width

    # 3. Porta FIXA de 1m, posição aleatória ABAIXO da parede
    door_width = 1.0
    max_door_top = env.inner_wall_y - 0.5
    max_start = max(0.2, max_door_top - door_width)
    door_start_y = np.random.uniform(0.2, max_start)
    env.door_ymin = door_start_y
    env.door_ymax = door_start_y + door_width
    
    # Goal alinhado com a porta
    env.goal_ymin = door_start_y + 0.2
    env.goal_ymax = env.door_ymax - 0.2


def set_start_random_wild(env):
    """
    Cenário Genérico de Generalização Extrema: Líder e Seguidor nascem em regiões 
    absolutamente randômicas, e A SALA TAMBÉM MUDA DE FORMATO. Testa o verdadeiro 
    instinto de navegação da rede baseada apenas em Radares(LiDAR) e Inércia(Stack).
    """
    env.domain_rand = False  # Desliga randomização do reset() para preservar a geometria
    set_dynamic_geometry(env)
    env.reset()
    
    # Assegura que começam a fita distantes do objetivo
    env.passed_breach = False
    env.passed_door = False

def run_generalization_test(n_runs=3):
    """Roda N animações randômicas para checagem orgânica"""
    if not os.path.exists(MODEL_PATH):
        print(f"[ERRO] Arquivo de pesos '{MODEL_PATH}' não encontrado. O treinamento precisa terminar de gerar pelo menos 1 modelo para ser testado.")
        return

    # Iniciar Ambiente e Estruturas da Cabeça do Robô
    env = LeaderFollowerEnv()
    try:
        obs_dim = len(env.reset())
        policy = DuelingDQN(obs_dim, env.na).to(DEVICE)
        policy.load_state_dict(torch.load(MODEL_PATH, map_location=DEVICE, weights_only=True))
        policy.eval()
    except Exception as e:
        print(f"Erro ao emparelhar o cérebro do robô (DuelingDQN): {e}")
        return

    agent = EvalAgent(policy, env, DEVICE)
    print(f"==== TESTE DE GENERALIZAÇÃO ====\nModelo '{MODEL_PATH}' carregado.")

    out_folder = "logs/generalization"
    os.makedirs(out_folder, exist_ok=True)

    print("\nExecutando Bateria Visual (Trajetórias em Terreno Desconhecido):")
    for i in range(1, n_runs + 1):
        test_name = f"random_{i}"
        print(f" -> Rodando Experimento {i}/{n_runs}...")
        
        csv_path = run_episode_collect(agent, set_start_random_wild, episode_id=test_name, out_dir=out_folder)
        plot_episode(csv_path)
        animate_episode(csv_path)

    print("\nCalculando Taxas Brutas de Sucesso via Força-Bruta Randômica...")
    evaluate_difficulty(agent, set_start_random_wild, "GENERALIZACAO_ALEATORIA", n_episodes=500)
    print(f"\nOs Gifs Gerados de prova cega foram salvos em: {out_folder}")

if __name__ == "__main__":
    run_generalization_test()
