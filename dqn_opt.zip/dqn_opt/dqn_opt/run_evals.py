import sys
from eval_scenarios import run_eval
import test

with open('eval_results_clean.txt', 'w', encoding='utf-8') as f:
    # Redirecionar stdout
    original_stdout = sys.stdout
    sys.stdout = f
    print("=== EVAL SCENARIOS ===")
    run_eval()
    print("=== GENERALIZATION TEST ===")
    test.run_generalization_test(n_runs=0) # Only evaluate_difficulty, no animation needed
    sys.stdout = original_stdout

print("Done evaluating")
