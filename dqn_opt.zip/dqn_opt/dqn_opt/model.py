import torch
import torch.nn as nn

class DuelingDQN(nn.Module):
    def __init__(self, inp: int, out: int, h: int = 256):
        super().__init__()
        # Extrator de features com LayerNorm (#5, #6)
        self.fe = nn.Sequential(
            nn.Linear(inp, h),
            nn.LayerNorm(h),
            nn.ReLU(),
            nn.Linear(h, h),
            nn.LayerNorm(h),
            nn.ReLU(),
            nn.Linear(h, h),
            nn.LayerNorm(h),
            nn.ReLU(),
        )
        
        # Fluxo de Valor (V)
        self.v_head = nn.Sequential(
            nn.Linear(h, h // 2),
            nn.ReLU(),
            nn.Linear(h // 2, 1)
        )
        
        # Fluxo de Vantagem (A)
        self.a_head = nn.Sequential(
            nn.Linear(h, h // 2),
            nn.ReLU(),
            nn.Linear(h // 2, out)
        )

    def forward(self, x):
        feat = self.fe(x)
        v = self.v_head(feat)
        a = self.a_head(feat)
        return v + (a - a.mean(dim=1, keepdim=True))
