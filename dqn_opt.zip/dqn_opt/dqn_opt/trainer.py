import time
import random
import numpy as np
import multiprocessing as mp
import torch
import torch.nn as nn
import torch.optim as optim
from dataclasses import dataclass
import matplotlib.pyplot as plt
import os
from tqdm import tqdm

from env import LeaderFollowerEnv
from model import DuelingDQN

@dataclass
class TrainConfig:
    gamma: float = 0.99
    batch: int = 128
    lr: float = 5e-4
    buffer_capacity: int = 100000
    min_buffer: int = 2000
    eps_start: float = 1.0
    eps_min: float = 0.02
    eps_decay_per_episode: float = 0.9997  # (#11) Decay por episódio, não por step
    max_episodes: int = 20000
    train_every: int = 1
    tau: float = 0.005
    
    # PER
    per_alpha: float = 0.6
    per_beta_start: float = 0.4
    per_beta_frames: int = 100000
    
    grad_steps_per_update: int = 1
    grad_clip_norm: float = 10.0   # (#8) Gradient clipping
    print_every_episodes: int = 200

def env_worker(remote, seed: int):
    env = LeaderFollowerEnv()
    while True:
        cmd, data = remote.recv()
        if cmd == "step":
            remote.send(env.step(data))
        elif cmd == "reset":
            remote.send(env.reset())
        elif cmd == "curriculum":
            env.curriculum_update(data)
        elif cmd == "obs":
            remote.send(env._state())
        elif cmd == "close":
            remote.close()
            break
        else:
            raise NotImplementedError

class ParallelEnvs:
    def __init__(self, n_envs):
        self.n_envs = n_envs
        self.remotes, self.work_remotes = zip(*[mp.Pipe() for _ in range(n_envs)])
        self.ps = [
            mp.Process(target=env_worker, args=(work, i))
            for i, work in enumerate(self.work_remotes)
        ]
        for p in self.ps:
            p.daemon = True
            p.start()

        for remote in self.work_remotes:
            remote.close()

        self.reset_all()

    def reset_all(self):
        for remote in self.remotes:
            remote.send(("reset", None))
        self.obs = np.stack([remote.recv() for remote in self.remotes])
        return self.obs

    def curriculum_update(self, episode):
        for remote in self.remotes:
            remote.send(("curriculum", episode))

    def step(self, actions):
        for i, remote in enumerate(self.remotes):
            remote.send(("step", actions[i]))
        
        results = [remote.recv() for remote in self.remotes]
        obs, rewards, dones, infos = zip(*results)
        
        obs = list(obs)
        for i in range(self.n_envs):
            if dones[i]:
                self.remotes[i].send(("reset", None))
                obs[i] = self.remotes[i].recv()
        
        self.obs = np.stack(obs)
        return self.obs, np.array(rewards), np.array(dones), infos

class SumTree:
    def __init__(self, capacity):
        self.capacity = capacity
        self.tree = np.zeros(2 * capacity - 1)
        self.data = np.zeros(capacity, dtype=object)
        self.data_idx = 0

    def add(self, p, data):
        idx = self.data_idx + self.capacity - 1
        self.data[self.data_idx] = data
        self.update(idx, p)
        self.data_idx = (self.data_idx + 1) % self.capacity

    def update(self, idx, p):
        # (#10) Proteger contra NaN e valores inválidos
        p = max(float(p), 1e-8)
        if not np.isfinite(p):
            p = 1e-8
        change = p - self.tree[idx]
        self.tree[idx] = p
        self._propagate(idx, change)

    def _propagate(self, idx, change):
        parent = (idx - 1) // 2
        self.tree[parent] += change
        if parent != 0:
            self._propagate(parent, change)

    def get(self, s):
        idx = self._retrieve(0, s)
        data_idx = idx - self.capacity + 1
        return idx, self.tree[idx], self.data[data_idx]

    def _retrieve(self, idx, s):
        left = 2 * idx + 1
        right = left + 1
        if left >= len(self.tree):
            return idx
        if s <= self.tree[left] or self.tree[right] == 0:
            return self._retrieve(left, s)
        return self._retrieve(right, s - self.tree[left])

class PrioritizedReplayBuffer:
    def __init__(self, capacity: int, alpha: float):
        self.capacity = int(capacity)
        self.alpha = alpha
        self.tree = SumTree(capacity)
        self.max_priority = 1.0
        self.size = 0
        self.lock = mp.Lock()

    def push(self, s, a, r, ns, d):
        with self.lock:
            self.tree.add(self.max_priority ** self.alpha, (s, a, r, ns, d))
            self.size = min(self.size + 1, self.capacity)

    def sample(self, batch_size: int, beta: float):
        with self.lock:
            batch = []
            idxs = []
            total = self.tree.tree[0]
            if total <= 0 or not np.isfinite(total):  # (#10) Proteção extra
                total = 1.0
            segment = total / batch_size
            priorities = []
            
            for i in range(batch_size):
                a = segment * i
                b = segment * (i + 1)
                s = random.uniform(a, b)
                idx, p, data = self.tree.get(s)
                batch.append(data)
                idxs.append(idx)
                priorities.append(max(p, 1e-8))
                
            sampling_probabilities = np.array(priorities) / max(total, 1e-8)
            is_weights = np.power(self.capacity * sampling_probabilities + 1e-8, -beta)
            is_weights /= is_weights.max()
            
            s, a, r, ns, d = map(np.stack, zip(*batch))
            return s, a, r, ns, d, idxs, np.array(is_weights, dtype=np.float32)

    def update_priorities(self, idxs, priorities):
        with self.lock:
            for idx, p in zip(idxs, priorities):
                p = max(float(p), 1e-8)
                self.max_priority = max(self.max_priority, p)
                self.tree.update(idx, p ** self.alpha)

    def __len__(self):
        return self.size

class DQNParallelTrainer:
    def __init__(self, n_envs: int, cfg: TrainConfig, device: torch.device):
        self.cfg = cfg
        self.device = device
        self.envs = ParallelEnvs(n_envs)
        
        sample_env = LeaderFollowerEnv()
        sample_obs = sample_env.reset()
        obs_dim = len(sample_obs)
        self.act_dim = sample_env.na

        self.policy = DuelingDQN(obs_dim, self.act_dim).to(device)
        self.target = DuelingDQN(obs_dim, self.act_dim).to(device)
        self.target.load_state_dict(self.policy.state_dict())

        self.opt = optim.Adam(self.policy.parameters(), lr=cfg.lr)
        self.buf = PrioritizedReplayBuffer(cfg.buffer_capacity, cfg.per_alpha)
        
        # AMP
        self.scaler = torch.amp.GradScaler("cuda") if device.type == "cuda" else None

        self.episode_count = 0
        self.total_transitions = 0
        self.eps = cfg.eps_start
        self.episode_rewards = [0.0] * n_envs
        self.last_logged_episode = -1
        
        # Histórico para Gráficos
        self.history_rewards = []     # (#7) Recompensa ACUMULADA do episódio
        self.history_eps = []
        
        # (#9) Melhor modelo
        self.best_avg_reward = -float('inf')
        
        os.makedirs("logs", exist_ok=True)

    def act_batch(self, obs):
        if random.random() < self.eps:
            return [random.randrange(self.act_dim) for _ in range(len(obs))]
        
        with torch.no_grad():
            t = torch.tensor(obs, dtype=torch.float32, device=self.device)
            q = self.policy(t)
            return q.argmax(dim=1).cpu().tolist()

    def update(self, beta: float):
        if len(self.buf) < self.cfg.min_buffer:
            return

        for _ in range(self.cfg.grad_steps_per_update):
            s, a, r, ns, d, idxs, is_weights = self.buf.sample(self.cfg.batch, beta)
            s = torch.tensor(s, dtype=torch.float32, device=self.device)
            a = torch.tensor(a, dtype=torch.long, device=self.device)
            r = torch.tensor(r, dtype=torch.float32, device=self.device)
            ns = torch.tensor(ns, dtype=torch.float32, device=self.device)
            d = torch.tensor(d, dtype=torch.float32, device=self.device)
            is_weights_t = torch.tensor(is_weights, dtype=torch.float32, device=self.device)

            with torch.amp.autocast("cuda", enabled=(self.scaler is not None)):
                q = self.policy(s).gather(1, a.unsqueeze(1)).squeeze(1)
                
                with torch.no_grad():
                    # Double DQN
                    best_next_actions = self.policy(ns).argmax(dim=1, keepdim=True)
                    max_next = self.target(ns).gather(1, best_next_actions).squeeze(1)
                    target = r.view(-1) + (1.0 - d.view(-1)) * self.cfg.gamma * max_next.view(-1)

                td_errors = torch.abs(target - q).detach().cpu().numpy()
                loss = (is_weights_t * nn.SmoothL1Loss(reduction='none')(q, target)).mean()

            self.buf.update_priorities(idxs, td_errors + 1e-6)

            self.opt.zero_grad(set_to_none=True)
            if self.scaler:
                self.scaler.scale(loss).backward()
                self.scaler.unscale_(self.opt)
                # (#8) Gradient clipping
                torch.nn.utils.clip_grad_norm_(self.policy.parameters(), self.cfg.grad_clip_norm)
                self.scaler.step(self.opt)
                self.scaler.update()
            else:
                loss.backward()
                # (#8) Gradient clipping
                torch.nn.utils.clip_grad_norm_(self.policy.parameters(), self.cfg.grad_clip_norm)
                self.opt.step()
                
            # Soft Update (Polyak Averaging)
            with torch.no_grad():
                for target_param, model_param in zip(self.target.parameters(), self.policy.parameters()):
                    target_param.data.copy_(
                        self.cfg.tau * model_param.data + (1.0 - self.cfg.tau) * target_param.data
                    )

    def train(self):
        start_time = time.time()
        obs = self.envs.obs
        
        pbar = tqdm(total=self.cfg.max_episodes, desc="Treinando DQN", unit="ep")

        while self.episode_count < self.cfg.max_episodes:
            actions = self.act_batch(obs)
            next_obs, rewards, dones, infos = self.envs.step(actions)

            for i in range(self.envs.n_envs):
                self.buf.push(obs[i], actions[i], rewards[i], next_obs[i], float(dones[i]))
                self.episode_rewards[i] += rewards[i]

                if dones[i]:
                    self.episode_count += 1
                    pbar.update(1)
                    
                    # (#7) Gravar recompensa ACUMULADA do episódio
                    ep_reward = self.episode_rewards[i]
                    self.history_rewards.append(float(ep_reward))
                    self.history_eps.append(self.eps)
                    
                    self.episode_rewards[i] = 0.0

                    # (#11) Epsilon decay por episódio
                    self.eps = max(self.cfg.eps_min, self.eps * self.cfg.eps_decay_per_episode)

                    # Curriculum Learning
                    self.envs.curriculum_update(self.episode_count)

                    if (self.episode_count > 0 and 
                        self.episode_count % self.cfg.print_every_episodes == 0 and 
                        self.episode_count != self.last_logged_episode):
                        
                        avg_reward = np.mean(self.history_rewards[-self.cfg.print_every_episodes:])
                        pbar.set_postfix({
                            "Eps": f"{self.eps:.3f}", 
                            "Buffer": len(self.buf), 
                            "AvgRew": f"{avg_reward:.1f}"
                        })
                        
                        # (#9) Salvar melhor modelo
                        if avg_reward > self.best_avg_reward:
                            self.best_avg_reward = avg_reward
                            torch.save(self.policy.state_dict(), "best_model.pth")
                        
                        self._save_training_plot()
                        self.last_logged_episode = self.episode_count

            obs = next_obs
            self.total_transitions += self.envs.n_envs

            if (self.total_transitions // self.envs.n_envs) % self.cfg.train_every == 0:
                fraction = min(1.0, float(self.total_transitions) / self.cfg.per_beta_frames)
                beta = self.cfg.per_beta_start + fraction * (1.0 - self.cfg.per_beta_start)
                self.update(beta)

        pbar.close()
        
        total_time = time.time() - start_time
        print("\n================ TREINO FINALIZADO ================")
        print(f"Total de episódios: {self.episode_count}")
        print(f"Tempo total de treino: {time.strftime('%H:%M:%S', time.gmtime(total_time))}")
        print(f"Tempo médio por episódio: {total_time/max(1, self.episode_count):.3f} s")
        print(f"Melhor recompensa média: {self.best_avg_reward:.1f}")
        print("===================================================\n")
        self._save_training_plot()

    def _save_training_plot(self):
        if not self.history_rewards:
            return

        fig, ax1 = plt.subplots(figsize=(10, 5))
        
        color = 'tab:blue'
        ax1.set_xlabel('Episódios Realizados')
        ax1.set_ylabel('Recompensa Acumulada do Episódio', color=color)
        
        window = min(100, max(1, len(self.history_rewards) // 10))
        smoothed_rewards = np.convolve(self.history_rewards, np.ones(window)/window, mode='valid')
        
        ax1.plot(self.history_rewards, alpha=0.3, color='lightblue', label="Recompensa Bruta")
        ax1.plot(range(window-1, len(self.history_rewards)), smoothed_rewards, color=color, linewidth=2, label="Média Móvel")
        ax1.tick_params(axis='y', labelcolor=color)
        ax1.grid(True, alpha=0.3)
        ax1.legend(loc='upper left')

        ax2 = ax1.twinx()
        color = 'tab:red'
        ax2.set_ylabel('Epsilon (Grau de Exploração) ε', color=color)
        ax2.plot(self.history_eps, color=color, linewidth=2, linestyle='--', label="Taxa Epsilon")
        ax2.tick_params(axis='y', labelcolor=color)
        ax2.legend(loc='upper right')

        fig.tight_layout()
        plt.title(f"Acompanhamento DQN — Ep: {self.episode_count}")
        plt.savefig(os.path.join("logs", "training_progress_live.png"))
        plt.close(fig)
