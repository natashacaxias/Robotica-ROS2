import sys
from utils import EvalAgent, evaluate_difficulty, set_start_easy, set_start_medium, set_start_hard
from test import set_start_random_wild
from env import LeaderFollowerEnv
from model import DuelingDQN
import torch

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
MODEL_PATH = "model.pth"

env = LeaderFollowerEnv()
policy = DuelingDQN(env.stack_size * 16, env.na).to(DEVICE)
policy.load_state_dict(torch.load(MODEL_PATH, map_location=DEVICE, weights_only=True))
policy.eval()

agent = EvalAgent(policy, env, DEVICE)

scenarios = [
    ("easy", set_start_easy),
    ("medium", set_start_medium),
    ("hard", set_start_hard),
    ("generalization", set_start_random_wild)
]

for name, start_fn in scenarios:
    evaluate_difficulty(agent, start_fn, name, n_episodes=100)
