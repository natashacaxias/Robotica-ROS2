import numpy as np
from collections import deque

class LeaderFollowerEnv:
    def __init__(self):
        # Fisica
        self.dt = 0.05
        self.sub = 4
        self.delay = 4
        self.buf_size = 200

        # Ações Golden Ratio (Proporção Áurea)
        phi = (1 + np.sqrt(5)) / 2.0
        
        # 5 Valores de V (0.0 até 0.5, crescendo com potências de phi)
        v_powers = [phi**-i for i in reversed(range(4))] # phi^-3, phi^-2, phi^-1, 1
        self.v_vals = np.array([0.0] + [0.5 * p for p in v_powers])
        
        # 8 Valores de W (-1.0 até 1.0, em simetria de potências de phi)
        w_powers = [phi**-i for i in reversed(range(4))]
        w_pos = np.array([1.0 * p for p in w_powers])
        self.w_vals = np.concatenate((-w_pos[::-1], w_pos))
        self.na = len(self.v_vals) * len(self.w_vals)

        # Seguidor
        self.max_v_f = 0.45
        self.kp_d = 0.8
        self.kp_a = 1.4
        self.kd_d = 0.1
        self.kd_a = 0.1
        self.prev_dist_err = 0.0
        self.prev_ang_err = 0.0

        # ---- GEOMETRIA DA SALA 8x8 ----
        self.room_xmin = 0.0
        self.room_xmax = 8.0
        self.room_ymin = 0.0
        self.room_ymax = 8.0

        # Parede interna horizontal em y=4, de x=0 ate x=6
        self.inner_wall_y = 4.0
        self.inner_wall_xmin = 0.0
        self.inner_wall_xmax = 6.0

        # Gap (brecha) de x=6 ate x=8 (lado direito)
        self.gap_xmin = 6.0
        self.gap_xmax = 8.0

        # Porta de saida na parede DIREITA, PERTO DA PAREDE INFERIOR
        self.door_ymin = 0.5
        self.door_ymax = 1.5

        # Zona de spawn — ACIMA da parede interna (expandida)
        self.spawn_xmin = 0.5
        self.spawn_xmax = 7.5
        self.spawn_ymin = 5.0
        self.spawn_ymax = 7.0

        # Goal — fora da sala, 2m da porta (x=8.0 + 2.0 = 10.0)
        self.goal_xmin = 9.8
        self.goal_xmax = 10.2
        self.goal_ymin = 0.7
        self.goal_ymax = 1.3

        # Seguranca (P3-AT: ~0.5m largura)
        self.min_safe_dist = 0.65
        self.collision_dist = 0.50
        self.desired_dist = 0.90
        self.spawn_radius = 1.00  # Max spawn distance

        # Curriculum Learning + Domain Randomization
        self.curriculum_episode = 0
        self.rand_strength = 0.0
        self.base_gap_size = 4.0
        self.base_door_size = 3.0
        self.domain_rand = True  # Desligar para eval/test externo

        # Estado
        self.goal = None
        self.leader = np.zeros(3)
        self.follower = np.zeros(3)
        self.buffer = deque(maxlen=self.buf_size)
        
        # Frame Stacking (Memória de Inércia)
        self.stack_size = 3
        self.frame_stack = deque(maxlen=self.stack_size)

        # Checkpoints
        self.passed_breach = False
        self.passed_door = False

        # Logging
        self.v_leader = 0.0
        self.w_leader = 0.0
        self.v_follower = 0.0
        self.w_follower = 0.0
        self.last_v_leader = 0.0
        self.last_w_leader = 0.0

        # Timeout por episódio
        self.max_steps = 600
        self.step_count = 0

        # --- LiDAR: 21 Raios (-60° a +60°) ---
        self.lidar_angles = np.linspace(-np.pi/3, np.pi/3, 21)
        self.lidar_num_steps = 20  
        self.lidar_max_dist = 3.0

        # Curriculum de Rigor (Segurança Progressiva)
        self.base_collision_dist = 0.35  # Começa "folgado"
        self.target_collision_dist = 0.50 # Termina "rigoroso"
        # Modificações para Scenarios Avançados
        self.extra_walls = [] 
        self.pillars = [] # Lista de (x, y, radius)
        self.wall_angle = 0.0 # Em radianos
        self.use_dynamic_target = True
        self.forced_goal = None

    @staticmethod
    def wrap(a):
        return (a + np.pi) % (2 * np.pi) - np.pi

    def _collides_walls_list(self, p1, p2, walls):
        x1, y1 = p1
        x2, y2 = p2
        radius = self.collision_dist / 2.0
        
        # Helper para checar se um ponto (x,y) está batendo em uma parede horizontal wy
        def point_on_wall(px, py, w_obj):
            wy = w_obj['y']
            if abs(py - wy) < radius:
                # Está no Y da parede. Checa se o X está na parte sólida (fora do gap)
                return px < w_obj['gap_xmin'] + radius or px > w_obj['gap_xmax'] - radius
            return False

        # 1. Checa se o ponto de destino p2 já está em colisão
        for w in walls:
            if abs(w.get('angle', 0.0)) < 1e-6:
                if point_on_wall(x2, y2, w): return True

        # 2. Checa interseção de segmento (original)
        for w in walls:
            wy = w['y']
            angle = w.get('angle', 0.0)
            if abs(angle) < 1e-6:
                if (y1 - wy) * (y2 - wy) <= 0:
                    if abs(y2 - y1) > 1e-9:
                        t = (wy - y1) / (y2 - y1)
                        if 0 <= t <= 1:
                            xcross = x1 + t * (x2 - x1)
                            if not (w['gap_xmin'] + radius < xcross < w['gap_xmax'] - radius):
                                return True
            else:
                # Rotação (mantido do original)
                c, s = np.cos(-angle), np.sin(-angle)
                cx, cy = w.get('cx', 4.0), wy
                def rotate(p):
                    rx, ry = p[0] - cx, p[1] - cy
                    return rx * c - ry * s + cx, rx * s + ry * c + cy
                rp1, rp2 = rotate(p1), rotate(p2)
                if (rp1[1] - cy) * (rp2[1] - cy) <= 0:
                    if abs(rp2[1] - rp1[1]) > 1e-9:
                        t = (cy - rp1[1]) / (rp2[1] - rp1[1])
                        rxcross = rp1[0] + t * (rp2[0] - rp1[0])
                        if not (w['gap_xmin'] + radius < rxcross < w['gap_xmax'] - radius):
                            return True
        return False

    def _collides_pillars(self, x, y):
        radius = self.collision_dist / 2.0
        for px, py, pr in self.pillars:
            dist = np.hypot(x - px, y - py)
            if dist < (pr + radius):
                return True
        return False

    def _collides_inner_wall(self, p1, p2):
        standard_wall = [{
            'y': self.inner_wall_y,
            'gap_xmin': self.gap_xmin,
            'gap_xmax': self.gap_xmax,
            'angle': self.wall_angle,
            'cx': (self.gap_xmin + self.gap_xmax) / 2.0
        }]
        if self._collides_walls_list(p1, p2, standard_wall): return True
        if self.extra_walls and self._collides_walls_list(p1, p2, self.extra_walls): return True
        if self._collides_pillars(p2[0], p2[1]): return True
        return False

    def _collides_room_walls(self, x, y):
        radius = self.collision_dist / 2.0
        if x < self.room_xmin + radius or y < self.room_ymin + radius or y > self.room_ymax - radius:
            return True
        
        # Parede Direita (Saída 8.0m): Só bloqueia se não estiver na porta.
        # Uma vez que passou para fora (x > 8.0 + radius), o robô está livre.
        if self.room_xmax - radius < x < self.room_xmax + radius:
            if not (self.door_ymin + radius <= y <= self.door_ymax - radius):
                return True
        return False

    def _is_through_breach(self, x, y):
        return (y < self.inner_wall_y and self.gap_xmin <= x <= self.gap_xmax)

    def _is_through_door(self, x, y):
        return (x >= self.room_xmax and self.door_ymin <= y <= self.door_ymax)

    def _step_uni(self, pose, v, w):
        x, y, th = pose
        for _ in range(self.sub):
            nx = x + self.dt * v * np.cos(th)
            ny = y + self.dt * v * np.sin(th)
            nth = self.wrap(th + self.dt * w)
            if self._collides_inner_wall((x, y), (nx, ny)): return np.array([x, y, nth]), True
            if self._collides_room_walls(nx, ny): return np.array([x, y, nth]), True
            x, y, th = nx, ny, nth
        return np.array([x, y, th]), False

    def _foll_ctrl(self, pose, tgt):
        x, y, th = pose
        tx, ty = tgt
        dx, dy = tx - x, ty - y
        
        # Erros atuais (Proporcional)
        dist = np.hypot(dx, dy)
        ang = np.arctan2(dy, dx)
        err = self.wrap(ang - th)
        
        # Erros passados (Derivativo)
        d_dist = dist - self.prev_dist_err
        d_err = self.wrap(err - self.prev_ang_err)
        
        # Atualiza o histórico
        self.prev_dist_err = dist
        self.prev_ang_err = err

        if dist < self.min_safe_dist:
            return 0.0, np.clip(self.kp_a * err, -1.0, 1.0)
            
        # Ganho Adaptativo: Reduz drásticamente a velocidade linear se o erro angular for alto
        # Ex: se err > 90 graus, cos(err) fica negativo. Limitamos o multiplicador a 0.2 (muito lento).
        # Em retas (err ~ 0), o multiplicador é 1.0.
        speed_factor = max(0.2, np.cos(err))
        eff_kp_d = self.kp_d * speed_factor

        # Controlador PD Adaptativo
        v_cmd = eff_kp_d * dist + self.kd_d * d_dist
        w_cmd = self.kp_a * err + self.kd_a * d_err
        
        v = np.clip(v_cmd, 0, self.max_v_f)
        w = np.clip(w_cmd, -1.5, 1.5)
        
        return v, w

    def _raycast(self, x, y, theta):
        """Dispara um raio e retorna a distância normalizada [0, 1] até o obstáculo mais próximo"""
        step_size = self.lidar_max_dist / self.lidar_num_steps
        for i in range(1, self.lidar_num_steps + 1):
            dist = i * step_size
            nx = x + dist * np.cos(theta)
            ny = y + dist * np.sin(theta)
            if self._collides_inner_wall((x, y), (nx, ny)) or self._collides_room_walls(nx, ny):
                return dist / self.lidar_max_dist
        return 1.0

    def _get_target(self):
        """Retorna o alvo atual baseado nos checkpoints, DINÂMICO com a geometria (#2)"""
        if not self.use_dynamic_target:
            return self.goal[0], self.goal[1]

        if not self.passed_breach:
            # Centro do gap (acompanha o currículo)
            tx = (self.gap_xmin + self.gap_xmax) / 2.0
            ty = self.inner_wall_y
            return tx, ty
        elif not self.passed_door:
            # Centro da porta (acompanha o currículo)
            tx = self.room_xmax
            ty = (self.door_ymin + self.door_ymax) / 2.0
            return tx, ty
        else:
            return self.goal[0], self.goal[1]

    def _state(self):
        Lx, Ly, Lth = self.leader
        Fx, Fy, Fth = self.follower
        
        tx, ty = self._get_target()

        dist_target = np.hypot(tx - Lx, ty - Ly)
        pair = np.hypot(Lx - Fx, Ly - Fy)
        heading = np.arctan2(ty - Ly, tx - Lx)
        ang = self.wrap(Lth - heading)
        
        # Ângulo relativo do seguidor visto pelo líder
        # 0 = seguidor na frente (PERIGO), ±π = atrás (seguro)
        angle_to_follower = self.wrap(np.arctan2(Fy - Ly, Fx - Lx) - Lth)
        
        # --- LiDAR Simulado (21 Raios) ---
        lidar = [self._raycast(Lx, Ly, self.wrap(Lth + a)) for a in self.lidar_angles]
        
        return np.array([
            tx - Lx, ty - Ly, dist_target, pair,
            np.sin(Lth), np.cos(Lth), np.sin(Fth), np.cos(Fth),
            ang,
            1.0 if self.passed_breach else 0.0,
            1.0 if self.passed_door else 0.0,
            self.last_v_leader,
            self.last_w_leader,
            np.sin(angle_to_follower), np.cos(angle_to_follower)
        ] + lidar, dtype=np.float32)

    def _get_stacked_state(self):
        """Retorna os últimos N estados concatenados em um único vetor 1D"""
        return np.concatenate(list(self.frame_stack))

    def curriculum_update(self, episode):
        """Atualiza a geometria do ambiente com base no progresso do treinamento.
        Fase 1 (0-10k): Fácil, geometria fixa
        Fase 2 (10k-30k): Transição + Domain Randomization crescente
        Fase 3 (30k+): Difícil + Domain Randomization completa
        """
        self.curriculum_episode = episode
        if episode < 10000:
            # Fase fácil: sem randomização (mais tempo para consolidar)
            self.rand_strength = 0.0
            self.base_gap_size = 3.0
            self.base_door_size = 2.0
        elif episode < 30000:
            t = (episode - 10000) / 20000.0  # 0 → 1
            self.rand_strength = t
            self.base_gap_size = 3.0 - t * 1.0   # 3.0 → 2.0
            self.base_door_size = 2.0 - t * 1.0   # 2.0 → 1.0
            
            # Evolução do Rigor de Colisão (0.35 -> 0.50)
            self.collision_dist = self.base_collision_dist + t * (self.target_collision_dist - self.base_collision_dist)
        else:
            self.rand_strength = 1.0
            self.base_gap_size = 2.0
            self.base_door_size = 1.0
            self.collision_dist = self.target_collision_dist

    def reset(self):
        # === Domain Randomization (apenas no treino) ===
        if self.domain_rand:
            s = self.rand_strength  # 0.0 (fixo) a 1.0 (full random)
            
            # Parede interna: y varia de 4.0 ± 1.0*s (mín 3.5 para caber a porta)
            self.inner_wall_y = max(3.5, 4.0 + np.random.uniform(-1.0, 1.0) * s)
            
            # Gap: tamanho base do currículo, posição varia com strength
            gap_size = self.base_gap_size
            max_gap_start = 8.0 - gap_size
            if s > 0:
                gap_start = np.random.uniform(0.0, max(0.0, max_gap_start))
            else:
                gap_start = 8.0 - gap_size
            self.inner_wall_xmax = gap_start
            self.gap_xmin = gap_start
            self.gap_xmax = gap_start + gap_size
            
            # Porta: tamanho limitado ao espaço disponível ABAIXO da parede
            available_space = self.inner_wall_y - 0.5 - 0.2
            door_size = min(self.base_door_size, max(0.8, available_space))
            max_door_top = self.inner_wall_y - 0.5
            max_start = max(0.2, max_door_top - door_size)
            if s > 0:
                door_start = np.random.uniform(0.2, max_start)
            else:
                door_start = max(0.0, max_door_top - door_size)
            self.door_ymin = door_start
            self.door_ymax = door_start + door_size
        
        if self.forced_goal is not None:
            self.goal = self.forced_goal.copy()

        # Spawn do líder (acima da parede interna)
        # Margem de segurança generosa para evitar spawn visualmente ou fisicamente colado na parede
        spawn_margin = 0.5
        spawn_ymin = self.inner_wall_y + spawn_margin
        spawn_ymax = min(self.room_ymax - spawn_margin, self.inner_wall_y + 2.5)
        
        # 1. Tenta Spawn do Líder sem colisão (Busca um ponto limpo)
        for _ in range(100):
            lx = np.random.uniform(self.room_xmin + spawn_margin, self.room_xmax - spawn_margin)
            ly = np.random.uniform(spawn_ymin, spawn_ymax)
            # Verifica colisão considerando o volume físico (radius)
            if not self._collides_room_walls(lx, ly) and not self._collides_inner_wall((lx, ly), (lx, ly)):
                break
        
        lth = np.random.uniform(-np.pi, np.pi)
        self.leader = np.array([lx, ly, lth])

        # 2. Tenta Spawn do Seguidor (respeitando as paredes e a distância do líder)
        for _ in range(100):
            ang = np.random.uniform(0, 2 * np.pi)
            d = np.random.uniform(0.80, self.spawn_radius)
            fx, fy = lx + d * np.cos(ang), ly + d * np.sin(ang)
            
            # Checa se o ponto central + radius está dentro dos limites da sala e livre de obstáculos
            if (self.room_xmin + spawn_margin < fx < self.room_xmax - spawn_margin and 
                self.room_ymin + spawn_margin < fy < self.room_ymax - spawn_margin):
                if not self._collides_room_walls(fx, fy) and not self._collides_inner_wall((fx, fy), (fx, fy)):
                    break
        
        self.follower = np.array([fx, fy, np.random.uniform(-np.pi, np.pi)])
        self.goal = np.array([np.random.uniform(self.goal_xmin, self.goal_xmax),
                             np.random.uniform(self.door_ymin + 0.1, self.door_ymax - 0.1)])
        self.passed_breach = False
        self.passed_door = False
        self.buffer.clear()
        self.buffer.append(self.leader[:2].copy())
        
        initial_state = self._state()
        for _ in range(self.stack_size):
            self.frame_stack.append(initial_state)
            
        self.last_dist_target = initial_state[2] 
        self.last_v_leader = 0.0
        self.last_w_leader = 0.0
        self.step_count = 0
        
        # Reset PD errors
        Lx, Ly, Lth = self.leader
        Fx, Fy, Fth = self.follower
        self.prev_dist_err = np.hypot(Lx - Fx, Ly - Fy)
        self.prev_ang_err = self.wrap(np.arctan2(Ly - Fy, Lx - Fx) - Fth)
        
        return self._get_stacked_state()

    def step(self, action: int):
        self.step_count += 1
        vi = action // 8
        wi = action % 8
        v, w = self.v_vals[vi], self.w_vals[wi]
        self.leader, l_collided = self._step_uni(self.leader, v, w)
        self.v_leader, self.w_leader = v, w
        self.buffer.append(self.leader[:2].copy())
        idx = max(0, len(self.buffer) - 1 - self.delay)
        vf, wf = self._foll_ctrl(self.follower, self.buffer[idx])
        self.follower, f_collided = self._step_uni(self.follower, vf, wf)
        self.v_follower, self.w_follower = vf, wf

        st = self._state()
        dist_target = st[2]
        pair = st[3]
        ang = abs(st[8])

        # ======== RECOMPENSAS NORMALIZADAS ========
        reward = 0.0
        dist_delta = self.last_dist_target - dist_target
        reward += np.clip(5.0 * dist_delta, -1.0, 1.0)
        self.last_dist_target = dist_target
        reward += 0.1 * np.cos(ang)
        reward += 0.2 * self.v_leader * np.cos(ang)
        
        w_delta = abs(self.w_leader - self.last_w_leader)
        if w_delta > 0.8:
            reward -= 3.0 * w_delta
        else:
            reward -= 0.15 * w_delta
            
        self.last_v_leader = self.v_leader
        self.last_w_leader = self.w_leader

        dist_err = abs(pair - self.desired_dist)
        reward -= 0.3 * min(dist_err, 1.0)
        if dist_err < 0.15: reward += 0.1

        heading_diff = abs(self.wrap(self.leader[2] - self.follower[2]))
        reward -= 0.1 * heading_diff

        if pair < self.min_safe_dist:
            reward -= 2.0 * (self.min_safe_dist - pair)**2

        min_lidar = min(st[15:]) 
        if min_lidar < 0.33: 
            reward -= 0.5 * (1.0 - min_lidar)**4 

        # Seguidor consciencia de obstáculo
        safety_margin = self.collision_dist / 2.0 + 0.15
        fx, fy = self.follower[0], self.follower[1]
        f_near_wall = self._collides_room_walls(fx, fy)
        f_near_inner = self._collides_inner_wall((fx, fy), (fx, fy))
        f_near_pillars = self._collides_pillars(fx, fy)

        if f_near_wall or f_near_inner or f_near_pillars:
            reward -= 0.5

        # Checkpoints
        if not self.passed_breach and self._is_through_breach(self.leader[0], self.leader[1]):
            self.passed_breach = True
            tx, ty = self._get_target()
            self.last_dist_target = np.hypot(tx - self.leader[0], ty - self.leader[1])
            self.frame_stack.append(st)
            return self._get_stacked_state(), 10.0, False, {"checkpoint": "breach"}
            
        if self.passed_breach and not self.passed_door and self._is_through_door(self.leader[0], self.leader[1]):
            self.passed_door = True
            tx, ty = self._get_target()
            self.last_dist_target = np.hypot(tx - self.leader[0], ty - self.leader[1])
            self.frame_stack.append(st)
            return self._get_stacked_state(), 20.0, False, {"checkpoint": "door"}

        self.frame_stack.append(st)
        stacked_st = self._get_stacked_state()

        # --- PRIORIDADE DE TÉRMINO ---
        # 1. Sucesso (Goal)
        mx, my = self.goal
        dist_final = np.hypot(mx - self.leader[0], my - self.leader[1])
        if dist_final < 0.3:
            r_final = 50.0
            if abs(self.leader[1] - my) < 0.2: r_final += 10.0
            return stacked_st, r_final, True, {"reason": "passed_goal"}

        # 2. Colisões
        if l_collided or f_collided:
            return stacked_st, -100.0, True, {"reason": "wall_collision"}

        if pair < self.collision_dist: 
            return stacked_st, -100.0, True, {"reason": "collision"}

        # 3. Timeout
        if self.step_count >= self.max_steps:
            return stacked_st, -5.0, True, {"reason": "timeout"}

        return stacked_st, float(reward), False, {}

    def setup_scenario(self, name, door_width=None, angle=None):
        """Configura geometrias especiais para testes do artigo"""
        self.domain_rand = False
        self.use_dynamic_target = True
        self.extra_walls = []
        self.pillars = []
        self.wall_angle = 0.0
        self.forced_goal = None
        
        if name == "slalom":
            # Sem parede interna, apenas 3 pilares
            self.inner_wall_y = -10.0 # Role de pilar
            self.gap_xmin, self.gap_xmax = -20, 20
            # Pilares no caminho (Slalom)
            self.pillars = [
                (4.0, 5.0, 0.3), # Meio
                (2.0, 3.0, 0.3), # Esquerda
                (6.0, 1.5, 0.3), # Direita
            ]
            self.door_ymin, self.door_ymax = 0.5, 1.5
            self.forced_goal = np.array([10.0, 1.0])

        elif name == "diagonal":
            # Parede rotacionada
            self.inner_wall_y = 4.0
            self.wall_angle = angle if angle else np.radians(30)
            self.gap_xmin, self.gap_xmax = 3.0, 5.0 # Vão de 2m
            self.door_ymin, self.door_ymax = 0.5, 1.5
            self.forced_goal = np.array([10.0, 1.0])
            
        elif name == "stress_test":
            # Testa o limite de largura da porta
            width = door_width if door_width else 1.0
            self.inner_wall_y = 4.0
            self.gap_xmin, self.gap_xmax = 1.0, 7.0 
            self.door_ymin = 4.0 - width/2.0
            self.door_ymax = 4.0 + width/2.0
            self.forced_goal = np.array([10.0, 4.0])
