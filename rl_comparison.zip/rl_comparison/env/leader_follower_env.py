"""
Gymnasium-compatible wrapper around the original LeaderFollowerEnv.
The internal dynamics, reward function, observation, and action space
are UNCHANGED — this is a thin interface layer only.
"""
import numpy as np

# ── Import from local copy (no dependency on dqn_opt) ──
from env.core_env import LeaderFollowerEnv as _OriginalEnv


class LeaderFollowerEnv(_OriginalEnv):
    """Direct re-export of the original env for internal use."""
    pass


class LeaderFollowerGymEnv:
    """Thin Gymnasium-like wrapper (no gymnasium dependency required).

    Provides:
        reset()  -> (obs, info)
        step(a)  -> (obs, reward, terminated, truncated, info)
        observation_space.shape, action_space.n
    """

    class _ObsSpace:
        def __init__(self, shape):
            self.shape = shape

    class _ActSpace:
        def __init__(self, n):
            self.n = n

    def __init__(self):
        self._env = LeaderFollowerEnv()
        obs = self._env.reset()
        self.observation_space = self._ObsSpace(obs.shape)
        self.action_space = self._ActSpace(self._env.na)
        # Sanity assertions
        assert self.observation_space.shape == (108,), \
            f"Obs dim mismatch: {self.observation_space.shape}"
        assert self.action_space.n == 40, \
            f"Action dim mismatch: {self.action_space.n}"

    # ── Core API ──
    def reset(self, seed=None):
        if seed is not None:
            np.random.seed(seed)
        obs = self._env.reset()
        return obs, {}

    def step(self, action: int):
        obs, reward, done, info = self._env.step(action)
        reason = info.get("reason", "")
        terminated = done and reason != "timeout"
        truncated = done and reason == "timeout"
        return obs, reward, terminated, truncated, info

    # ── Delegated helpers ──
    @property
    def inner(self):
        """Access the raw LeaderFollowerEnv for curriculum / scenario setup."""
        return self._env

    def curriculum_update_by_step(self, curriculum, step):
        curriculum.apply_to_env(self._env, step)

    # Expose attributes needed by evaluation
    @property
    def leader(self):
        return self._env.leader

    @leader.setter
    def leader(self, v):
        self._env.leader = v

    @property
    def follower(self):
        return self._env.follower

    @follower.setter
    def follower(self, v):
        self._env.follower = v

    @property
    def goal(self):
        return self._env.goal

    @property
    def na(self):
        return self._env.na

    @property
    def dt(self):
        return self._env.dt

    @property
    def sub(self):
        return self._env.sub

    @property
    def v_leader(self):
        return self._env.v_leader

    @property
    def w_leader(self):
        return self._env.w_leader

    @property
    def v_follower(self):
        return self._env.v_follower

    @property
    def w_follower(self):
        return self._env.w_follower

    @property
    def inner_wall_y(self):
        return self._env.inner_wall_y

    @inner_wall_y.setter
    def inner_wall_y(self, v):
        self._env.inner_wall_y = v

    @property
    def inner_wall_xmax(self):
        return self._env.inner_wall_xmax

    @inner_wall_xmax.setter
    def inner_wall_xmax(self, v):
        self._env.inner_wall_xmax = v

    @property
    def gap_xmin(self):
        return self._env.gap_xmin

    @gap_xmin.setter
    def gap_xmin(self, v):
        self._env.gap_xmin = v

    @property
    def gap_xmax(self):
        return self._env.gap_xmax

    @gap_xmax.setter
    def gap_xmax(self, v):
        self._env.gap_xmax = v

    @property
    def door_ymin(self):
        return self._env.door_ymin

    @door_ymin.setter
    def door_ymin(self, v):
        self._env.door_ymin = v

    @property
    def door_ymax(self):
        return self._env.door_ymax

    @door_ymax.setter
    def door_ymax(self, v):
        self._env.door_ymax = v

    @property
    def domain_rand(self):
        return self._env.domain_rand

    @domain_rand.setter
    def domain_rand(self, v):
        self._env.domain_rand = v

    @property
    def passed_breach(self):
        return self._env.passed_breach

    @passed_breach.setter
    def passed_breach(self, v):
        self._env.passed_breach = v

    @property
    def passed_door(self):
        return self._env.passed_door

    @passed_door.setter
    def passed_door(self, v):
        self._env.passed_door = v

    @property
    def goal_ymin(self):
        return self._env.goal_ymin

    @goal_ymin.setter
    def goal_ymin(self, v):
        self._env.goal_ymin = v

    @property
    def goal_ymax(self):
        return self._env.goal_ymax

    @goal_ymax.setter
    def goal_ymax(self, v):
        self._env.goal_ymax = v

    @property
    def stack_size(self):
        return self._env.stack_size

    @property
    def frame_stack(self):
        return self._env.frame_stack

    @property
    def last_dist_target(self):
        return self._env.last_dist_target

    @last_dist_target.setter
    def last_dist_target(self, v):
        self._env.last_dist_target = v

    def _state(self):
        return self._env._state()

    def _get_stacked_state(self):
        return self._env._get_stacked_state()
