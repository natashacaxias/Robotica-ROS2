"""
Deterministic evaluation protocol shared by all algorithms.
Runs 100 episodes with no exploration on fixed-geometry scenarios.
"""
import os
import csv
import numpy as np

from env.leader_follower_env import LeaderFollowerEnv


# ══════════════════════════════════════════════════════════════
# Scenario setups (identical to original utils.py)
# ══════════════════════════════════════════════════════════════
def _set_eval_geometry(env):
    """Fixed geometry: gap 2m, door 1m."""
    env.domain_rand = False
    env.inner_wall_y = 4.0
    env.inner_wall_xmax = 6.0
    env.gap_xmin = 6.0
    env.gap_xmax = 8.0
    env.door_ymin = 0.5
    env.door_ymax = 1.5


def set_start_easy(env):
    _set_eval_geometry(env)
    env.reset()
    env.leader = np.array([7.0, 1.0, 0.0])
    env.follower = np.array([6.1, 1.0, 0.0])
    env.passed_breach = True
    env.passed_door = False


def set_start_medium(env):
    _set_eval_geometry(env)
    env.reset()
    env.leader = np.array([2.5, 6.0, -0.5])
    env.follower = np.array([1.7, 6.4, -0.5])
    env.passed_breach = False
    env.passed_door = False


def set_start_hard(env):
    _set_eval_geometry(env)
    env.reset()
    env.leader = np.array([3.0, 4.3, 0.0])
    env.follower = np.array([2.1, 4.3, 0.0])
    env.passed_breach = False
    env.passed_door = False


SCENARIOS = [
    ("easy", set_start_easy),
    ("medium", set_start_medium),
    ("hard", set_start_hard),
]


# ══════════════════════════════════════════════════════════════
# Core evaluation routine
# ══════════════════════════════════════════════════════════════
def _prepare_env_for_scenario(env, set_start_fn):
    """Set scenario and rebuild frame stack."""
    set_start_fn(env)
    initial_state = env._state()
    for _ in range(env.stack_size):
        env.frame_stack.append(initial_state)
    env.last_dist_target = initial_state[2]
    return env._get_stacked_state()


def run_eval(trainer, n_episodes: int = 100, seed: int = 0, use_current_curriculum: bool = False):
    """
    Run deterministic evaluation.
    
    Parameters
    ----------
    use_current_curriculum : bool
        If True, evaluation uses the trainer's current rand_strength/geometry.
        If False, uses fixed Phase 3 difficulty.
    """
    env = LeaderFollowerEnv()
    results = {}

    for name, setup_fn in SCENARIOS:
        successes = 0
        collisions = 0
        timeouts = 0
        total_reward = 0.0
        total_length = 0

        for ep in range(n_episodes):
            np.random.seed(seed * 10000 + ep)
            
            if use_current_curriculum:
                # Apply trainer's current curriculum before setting start pose
                trainer.curriculum.apply_to_env(env, trainer.global_step)
                env.domain_rand = False # Keep geometry deterministic for eval
                setup_fn(env) # Only sets positions/flags
            else:
                st = _prepare_env_for_scenario(env, setup_fn)
            
            # Ensure frame stack is fresh
            initial_state = env._state()
            env.frame_stack.clear()
            for _ in range(env.stack_size):
                env.frame_stack.append(initial_state)
            env.last_dist_target = initial_state[2]
            st = env._get_stacked_state()
            
            done = False
            ep_reward = 0.0
            steps = 0

            while not done and steps < 600:
                a = trainer.get_eval_action(st)
                st, r, done, info = env.step(a)
                ep_reward += r
                steps += 1

            reason = info.get("reason", "timeout")
            if reason == "passed_goal":
                successes += 1
            elif reason in ("collision", "wall_collision"):
                collisions += 1
            else:
                timeouts += 1

            total_reward += ep_reward
            total_length += steps

        results[name] = {
            "success_rate": successes / n_episodes,
            "collision_rate": collisions / n_episodes,
            "timeout_rate": timeouts / n_episodes,
            "avg_reward": total_reward / n_episodes,
            "avg_length": total_length / n_episodes,
        }

    return results


def save_eval_results(results: dict, step: int, out_dir: str):
    """Append evaluation results to a CSV."""
    os.makedirs(out_dir, exist_ok=True)
    filepath = os.path.join(out_dir, "eval_metrics.csv")

    write_header = not os.path.exists(filepath)
    with open(filepath, "a", newline="") as f:
        writer = csv.writer(f)
        if write_header:
            writer.writerow([
                "step", "scenario", "success_rate", "collision_rate",
                "timeout_rate", "avg_reward", "avg_length"
            ])
        for scenario, metrics in results.items():
            writer.writerow([
                step, scenario,
                f"{metrics['success_rate']:.4f}",
                f"{metrics['collision_rate']:.4f}",
                f"{metrics['timeout_rate']:.4f}",
                f"{metrics['avg_reward']:.2f}",
                f"{metrics['avg_length']:.1f}",
            ])
