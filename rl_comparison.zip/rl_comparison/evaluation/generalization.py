"""
Post-training generalization test: 500 episodes with dynamic geometry.
Same protocol as the original test.py but unified for all algorithms.
"""
import os
import csv
import numpy as np

from env.leader_follower_env import LeaderFollowerEnv


def _set_dynamic_geometry(env):
    """Randomised positions with fixed gap (2m) and door (1m) sizes."""
    env.inner_wall_y = np.random.uniform(3.5, 5.0)

    gap_width = 2.0
    gap_start = np.random.uniform(0.0, 8.0 - gap_width)
    env.inner_wall_xmin = 0.0
    env.inner_wall_xmax = gap_start
    env.gap_xmin = gap_start
    env.gap_xmax = gap_start + gap_width

    door_width = 1.0
    max_door_top = env.inner_wall_y - 0.5
    max_start = max(0.2, max_door_top - door_width)
    door_start_y = np.random.uniform(0.2, max_start)
    env.door_ymin = door_start_y
    env.door_ymax = door_start_y + door_width

    env.goal_ymin = door_start_y + 0.2
    env.goal_ymax = env.door_ymax - 0.2


def set_start_random_wild(env):
    """Generalisation scenario: random geometry, random spawn."""
    env.domain_rand = False
    _set_dynamic_geometry(env)
    env.reset()
    env.passed_breach = False
    env.passed_door = False


def run_generalization_test(trainer, n_episodes: int = 500, seed: int = 0):
    """
    Run the generalization battery.

    Returns
    -------
    dict : {success_rate, collision_rate, timeout_rate,
            wall_collision_rate, avg_reward, avg_length}
    """
    env = LeaderFollowerEnv()
    successes = 0
    collisions = 0
    wall_collisions = 0
    timeouts = 0
    total_reward = 0.0
    total_length = 0

    for ep in range(n_episodes):
        np.random.seed(seed * 100000 + ep)
        set_start_random_wild(env)

        initial_state = env._state()
        for _ in range(env.stack_size):
            env.frame_stack.append(initial_state)
        env.last_dist_target = initial_state[2]
        st = env._get_stacked_state()

        done = False
        ep_reward = 0.0
        steps = 0

        while not done and steps < 600:
            a = trainer.get_eval_action(st)
            st, r, done, info = env.step(a)
            ep_reward += r
            steps += 1

        reason = info.get("reason", "timeout")
        if reason == "passed_goal":
            successes += 1
        elif reason == "collision":
            collisions += 1
        elif reason == "wall_collision":
            wall_collisions += 1
        else:
            timeouts += 1

        total_reward += ep_reward
        total_length += steps

    return {
        "success_rate": successes / n_episodes,
        "collision_rate": collisions / n_episodes,
        "wall_collision_rate": wall_collisions / n_episodes,
        "timeout_rate": timeouts / n_episodes,
        "avg_reward": total_reward / n_episodes,
        "avg_length": total_length / n_episodes,
    }


def save_generalization_results(results: dict, out_dir: str):
    """Save generalization results to CSV."""
    os.makedirs(out_dir, exist_ok=True)
    filepath = os.path.join(out_dir, "generalization.csv")

    with open(filepath, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(list(results.keys()))
        writer.writerow([f"{v:.4f}" for v in results.values()])
