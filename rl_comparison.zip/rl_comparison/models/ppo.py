"""
PPO Actor-Critic with shared backbone.
Policy head: 40 logits (Categorical)
Value head:  1 scalar
"""
import torch
import torch.nn as nn
from torch.distributions import Categorical
from .backbone import SharedBackbone


class PPOActorCritic(nn.Module):
    def __init__(self, obs_dim: int = 108, n_actions: int = 40, h: int = 256):
        super().__init__()
        self.backbone = SharedBackbone(obs_dim, h)
        self.policy_head = nn.Linear(h, n_actions)
        self.value_head = nn.Linear(h, 1)

    def forward(self, x: torch.Tensor):
        features = self.backbone(x)
        logits = self.policy_head(features)
        value = self.value_head(features)
        return logits, value.squeeze(-1)

    def get_action_and_value(self, x: torch.Tensor, action=None):
        logits, value = self.forward(x)
        dist = Categorical(logits=logits)
        if action is None:
            action = dist.sample()
        log_prob = dist.log_prob(action)
        entropy = dist.entropy()
        return action, log_prob, entropy, value

    def get_value(self, x: torch.Tensor):
        features = self.backbone(x)
        return self.value_head(features).squeeze(-1)

    def get_deterministic_action(self, x: torch.Tensor):
        """For evaluation: pick the most probable action (greedy)."""
        logits, _ = self.forward(x)
        return logits.argmax(dim=-1)
