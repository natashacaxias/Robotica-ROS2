"""
Rainbow DQN: SharedBackbone → NoisyLinear Dueling heads.
Components: PER + Double DQN + Dueling + NoisyNet + n-step returns.
(No distributional/C51 to keep output shape = 40 Q-values.)
"""
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from .backbone import SharedBackbone


class NoisyLinear(nn.Module):
    """Factorised NoisyNet linear layer (Fortunato et al., 2018)."""

    def __init__(self, in_features: int, out_features: int, sigma_init: float = 0.5):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features

        self.weight_mu = nn.Parameter(torch.empty(out_features, in_features))
        self.weight_sigma = nn.Parameter(torch.empty(out_features, in_features))
        self.register_buffer("weight_epsilon", torch.empty(out_features, in_features))

        self.bias_mu = nn.Parameter(torch.empty(out_features))
        self.bias_sigma = nn.Parameter(torch.empty(out_features))
        self.register_buffer("bias_epsilon", torch.empty(out_features))

        self.sigma_init = sigma_init
        self._reset_parameters()
        self.reset_noise()

    def _reset_parameters(self):
        bound = 1.0 / math.sqrt(self.in_features)
        self.weight_mu.data.uniform_(-bound, bound)
        self.weight_sigma.data.fill_(self.sigma_init / math.sqrt(self.in_features))
        self.bias_mu.data.uniform_(-bound, bound)
        self.bias_sigma.data.fill_(self.sigma_init / math.sqrt(self.out_features))

    @staticmethod
    def _scale_noise(size: int) -> torch.Tensor:
        x = torch.randn(size)
        return x.sign() * x.abs().sqrt()

    def reset_noise(self):
        eps_in = self._scale_noise(self.in_features)
        eps_out = self._scale_noise(self.out_features)
        self.weight_epsilon.copy_(eps_out.outer(eps_in))
        self.bias_epsilon.copy_(eps_out)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.training:
            weight = self.weight_mu + self.weight_sigma * self.weight_epsilon
            bias = self.bias_mu + self.bias_sigma * self.bias_epsilon
        else:
            weight = self.weight_mu
            bias = self.bias_mu
        return F.linear(x, weight, bias)


class RainbowDQNNet(nn.Module):
    """
    Rainbow DQN = Dueling + NoisyNet heads on shared backbone.
    PER, Double DQN, and n-step are handled by the trainer.
    """

    def __init__(self, obs_dim: int = 108, n_actions: int = 40,
                 h: int = 256, sigma: float = 0.5):
        super().__init__()
        self.backbone = SharedBackbone(obs_dim, h)

        # Value stream (noisy)
        self.v_noisy1 = NoisyLinear(h, h // 2, sigma)
        self.v_noisy2 = NoisyLinear(h // 2, 1, sigma)

        # Advantage stream (noisy)
        self.a_noisy1 = NoisyLinear(h, h // 2, sigma)
        self.a_noisy2 = NoisyLinear(h // 2, n_actions, sigma)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        features = self.backbone(x)

        v = F.relu(self.v_noisy1(features))
        v = self.v_noisy2(v)

        a = F.relu(self.a_noisy1(features))
        a = self.a_noisy2(a)

        return v + (a - a.mean(dim=1, keepdim=True))

    def reset_noise(self):
        """Reset noise in all NoisyLinear layers (call each training step)."""
        self.v_noisy1.reset_noise()
        self.v_noisy2.reset_noise()
        self.a_noisy1.reset_noise()
        self.a_noisy2.reset_noise()
