"""
Shared MLP backbone used by ALL algorithms.
Architecture: 108 → 256(LN+ReLU) → 256(LN+ReLU) → 256(LN+ReLU)

This is IDENTICAL for DQN, Dueling DQN, PPO, and Rainbow.
Only the output heads differ.
"""
import torch
import torch.nn as nn


class SharedBackbone(nn.Module):
    """
    3-layer MLP feature extractor with LayerNorm.
    Matches the proven architecture from the original DuelingDQN.
    """

    def __init__(self, inp: int = 108, h: int = 256):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(inp, h),
            nn.LayerNorm(h),
            nn.ReLU(),
            nn.Linear(h, h),
            nn.LayerNorm(h),
            nn.ReLU(),
            nn.Linear(h, h),
            nn.LayerNorm(h),
            nn.ReLU(),
        )
        self.output_dim = h

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)
