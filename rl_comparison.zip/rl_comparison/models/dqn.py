"""
Vanilla DQN network: SharedBackbone → Linear(256, 40) Q-values.
"""
import torch
import torch.nn as nn
from .backbone import SharedBackbone


class DQNNet(nn.Module):
    def __init__(self, obs_dim: int = 108, n_actions: int = 40, h: int = 256):
        super().__init__()
        self.backbone = SharedBackbone(obs_dim, h)
        self.q_head = nn.Linear(h, n_actions)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        features = self.backbone(x)
        return self.q_head(features)
