"""
Dueling DQN: SharedBackbone → Value stream + Advantage stream.
Q(s,a) = V(s) + A(s,a) - mean(A(s,:))
"""
import torch
import torch.nn as nn
from .backbone import SharedBackbone


class DuelingDQNNet(nn.Module):
    def __init__(self, obs_dim: int = 108, n_actions: int = 40, h: int = 256):
        super().__init__()
        self.backbone = SharedBackbone(obs_dim, h)
        self.v_head = nn.Sequential(
            nn.Linear(h, h // 2),
            nn.ReLU(),
            nn.Linear(h // 2, 1),
        )
        self.a_head = nn.Sequential(
            nn.Linear(h, h // 2),
            nn.ReLU(),
            nn.Linear(h // 2, n_actions),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        features = self.backbone(x)
        v = self.v_head(features)
        a = self.a_head(features)
        return v + (a - a.mean(dim=1, keepdim=True))
