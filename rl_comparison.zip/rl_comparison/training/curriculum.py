"""
Step-based curriculum schedule shared by all algorithms.
Converts the original episode-based 3-phase curriculum to step thresholds.
"""
import numpy as np


class CurriculumSchedule:
    """Manages environment difficulty based on total training steps elapsed."""

    def __init__(self, phase1_end: int, phase2_end: int, total_steps: int):
        self.phase1_end = phase1_end
        self.phase2_end = phase2_end
        self.total_steps = total_steps

    def get_params(self, step: int) -> dict:
        """Return curriculum parameters for the given global step.

        Returns
        -------
        dict with keys:
            rand_strength : float   0→1
            gap_size      : float   metres
            door_size     : float   metres
            collision_dist: float   metres
        """
        if step < self.phase1_end:
            # Phase 1: easy, fixed geometry
            return {
                "rand_strength": 0.0,
                "gap_size": 3.0,
                "door_size": 2.0,
                "collision_dist": 0.35,
            }

        if step < self.phase2_end:
            # Phase 2: linear ramp
            t = (step - self.phase1_end) / max(1, self.phase2_end - self.phase1_end)
            return {
                "rand_strength": t,
                "gap_size": 3.0 - t * 1.0,       # 3.0 → 2.0
                "door_size": 2.0 - t * 1.0,       # 2.0 → 1.0
                "collision_dist": 0.35 + t * 0.15, # 0.35 → 0.50
            }

        # Phase 3: full difficulty + full randomisation
        return {
            "rand_strength": 1.0,
            "gap_size": 2.0,
            "door_size": 1.0,
            "collision_dist": 0.50,
        }

    def apply_to_env(self, env, step: int):
        """Apply curriculum parameters to a LeaderFollowerEnv instance."""
        p = self.get_params(step)
        env.rand_strength = p["rand_strength"]
        env.base_gap_size = p["gap_size"]
        env.base_door_size = p["door_size"]
        env.collision_dist = p["collision_dist"]
