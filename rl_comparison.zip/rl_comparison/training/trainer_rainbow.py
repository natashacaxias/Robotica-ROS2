"""
Rainbow DQN Trainer.
Components: PER + Double DQN + Dueling + NoisyNet + n-step returns.
No ε-greedy (NoisyNet handles exploration).
"""
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim

from models.rainbow import RainbowDQNNet
from training.replay_buffer import PrioritizedReplayBuffer, NStepBuffer
from training.curriculum import CurriculumSchedule


class RainbowTrainer:
    def __init__(self, cfg, device, curriculum: CurriculumSchedule):
        self.cfg = cfg
        self.device = device
        self.curriculum = curriculum

        self.policy = RainbowDQNNet(
            cfg.obs_dim, cfg.n_actions, cfg.hidden_size, cfg.noisy_sigma
        ).to(device)
        self.target = RainbowDQNNet(
            cfg.obs_dim, cfg.n_actions, cfg.hidden_size, cfg.noisy_sigma
        ).to(device)
        self.target.load_state_dict(self.policy.state_dict())
        self.target.eval()

        self.opt = optim.Adam(self.policy.parameters(), lr=cfg.lr)
        self.buf = PrioritizedReplayBuffer(cfg.buffer_capacity, cfg.per_alpha)
        self.n_step_buf = NStepBuffer(cfg.n_step, cfg.gamma)

        self.global_step = 0
        # Effective gamma for n-step target
        self.gamma_n = cfg.gamma ** cfg.n_step

    @property
    def name(self):
        return "rainbow"

    def _beta(self):
        frac = min(1.0, self.global_step / self.cfg.total_steps)
        return self.cfg.per_beta_start + frac * (self.cfg.per_beta_end - self.cfg.per_beta_start)

    def select_action(self, obs: np.ndarray) -> int:
        """NoisyNet exploration — no ε-greedy needed."""
        self.policy.reset_noise()
        with torch.no_grad():
            t = torch.tensor(obs, dtype=torch.float32, device=self.device).unsqueeze(0)
            return int(self.policy(t).argmax(dim=1).item())

    def store_transition(self, s, a, r, ns, d):
        result = self.n_step_buf.append(s, a, r, ns, float(d))
        if result is not None:
            self.buf.push(*result)
        # Flush at episode end
        if d:
            for item in self.n_step_buf.flush():
                self.buf.push(*item)

    def update(self):
        if len(self.buf) < self.cfg.min_buffer:
            return
        self.policy.reset_noise()
        self.target.reset_noise()

        beta = self._beta()
        s, a, r, ns, d, idxs, is_w = self.buf.sample(self.cfg.batch_size, beta)
        s = torch.tensor(s, dtype=torch.float32, device=self.device)
        a = torch.tensor(a, dtype=torch.long, device=self.device)
        r = torch.tensor(r, dtype=torch.float32, device=self.device)
        ns = torch.tensor(ns, dtype=torch.float32, device=self.device)
        d = torch.tensor(d, dtype=torch.float32, device=self.device)
        is_w = torch.tensor(is_w, dtype=torch.float32, device=self.device)

        q = self.policy(s).gather(1, a.unsqueeze(1)).squeeze(1)

        with torch.no_grad():
            # Double DQN: select action from policy, evaluate with target
            best_actions = self.policy(ns).argmax(dim=1, keepdim=True)
            max_next = self.target(ns).gather(1, best_actions).squeeze(1)
            # n-step target
            target_q = r + (1.0 - d) * self.gamma_n * max_next

        td_errors = torch.abs(target_q - q).detach().cpu().numpy()
        loss = (is_w * nn.SmoothL1Loss(reduction='none')(q, target_q)).mean()

        self.buf.update_priorities(idxs, td_errors + 1e-6)

        self.opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.policy.parameters(), self.cfg.grad_clip_norm)
        self.opt.step()

        # Soft update
        with torch.no_grad():
            for tp, mp in zip(self.target.parameters(), self.policy.parameters()):
                tp.data.copy_(self.cfg.tau * mp.data + (1.0 - self.cfg.tau) * tp.data)

    def step_done(self):
        self.global_step += 1

    def get_eval_action(self, obs: np.ndarray) -> int:
        """Deterministic: use mean weights (no noise in eval mode)."""
        self.policy.eval()
        with torch.no_grad():
            t = torch.tensor(obs, dtype=torch.float32, device=self.device).unsqueeze(0)
            result = int(self.policy(t).argmax(dim=1).item())
        self.policy.train()
        return result

    def save(self, path: str):
        torch.save(self.policy.state_dict(), path)

    def load(self, path: str):
        self.policy.load_state_dict(torch.load(path, map_location=self.device, weights_only=True))
        self.target.load_state_dict(self.policy.state_dict())
