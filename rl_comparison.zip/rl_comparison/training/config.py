"""
Frozen global configuration for the RL comparison experiment.
ALL algorithms share these exact parameters. No per-algorithm tuning allowed.
"""
from dataclasses import dataclass, field
from typing import List


@dataclass(frozen=True)
class ExperimentConfig:
    # ── Training Budget ──
    total_steps: int = 1_000_000
    num_envs: int = 1  # single env for fair step counting
    train_interval: int = 12 # update frequency (every 12 steps)

    # ── Optimiser ──
    lr: float = 3e-4
    batch_size: int = 128
    gamma: float = 0.99
    grad_clip_norm: float = 10.0

    # ── Network ──
    hidden_size: int = 256
    n_actions: int = 40
    obs_dim: int = 108

    # ── DQN family ──
    tau: float = 0.005
    buffer_capacity: int = 100_000
    min_buffer: int = 2_000
    eps_start: float = 1.0
    eps_min: float = 0.02
    # Decay computed so eps reaches eps_min around 70 % of training
    eps_decay_per_step: float = 0.999_994

    # ── PER (Dueling + Rainbow) ──
    per_alpha: float = 0.6
    per_beta_start: float = 0.4
    per_beta_end: float = 1.0

    # ── Rainbow extras ──
    n_step: int = 3
    noisy_sigma: float = 0.5

    # ── PPO ──
    ppo_clip: float = 0.2
    ppo_entropy_coef: float = 0.01
    ppo_value_coef: float = 0.5
    ppo_rollout_len: int = 2048
    ppo_epochs: int = 4
    ppo_gae_lambda: float = 0.95

    # ── Curriculum (step-based) ──
    curriculum_phase1_end: int = 250_000
    curriculum_phase2_end: int = 750_000
    # Phase 3 runs from phase2_end to total_steps

    # ── Evaluation ──
    eval_interval: int = 50_000
    eval_episodes: int = 100
    gen_episodes: int = 500

    # ── Seeds ──
    seeds: tuple = (42, 123, 456)

    # ── Algorithms ──
    algorithms: tuple = ("dqn", "dueling_dqn", "ppo", "rainbow")


CONFIG = ExperimentConfig()
