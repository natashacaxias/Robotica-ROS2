"""
Replay buffers for DQN-family algorithms.
- UniformReplayBuffer  : DQN
- PrioritizedReplayBuffer : Dueling DQN, Rainbow
- NStepBuffer : Rainbow (n-step returns helper)
"""
import random
import numpy as np


# ═══════════════════════════════════════════════════════════════════
# SumTree (for PER)
# ═══════════════════════════════════════════════════════════════════
class SumTree:
    def __init__(self, capacity: int):
        self.capacity = capacity
        self.tree = np.zeros(2 * capacity - 1)
        self.data = np.zeros(capacity, dtype=object)
        self.data_idx = 0
        self.size = 0

    def add(self, priority: float, data):
        idx = self.data_idx + self.capacity - 1
        self.data[self.data_idx] = data
        self._update(idx, priority)
        self.data_idx = (self.data_idx + 1) % self.capacity
        self.size = min(self.size + 1, self.capacity)

    def _update(self, idx: int, priority: float):
        priority = max(float(priority), 1e-8)
        if not np.isfinite(priority):
            priority = 1e-8
        change = priority - self.tree[idx]
        self.tree[idx] = priority
        self._propagate(idx, change)

    def _propagate(self, idx: int, change: float):
        parent = (idx - 1) // 2
        self.tree[parent] += change
        if parent != 0:
            self._propagate(parent, change)

    def get(self, s: float):
        idx = self._retrieve(0, s)
        data_idx = idx - self.capacity + 1
        return idx, self.tree[idx], self.data[data_idx]

    def _retrieve(self, idx: int, s: float):
        left = 2 * idx + 1
        right = left + 1
        if left >= len(self.tree):
            return idx
        if s <= self.tree[left] or self.tree[right] == 0:
            return self._retrieve(left, s)
        return self._retrieve(right, s - self.tree[left])

    @property
    def total(self):
        return self.tree[0]


# ═══════════════════════════════════════════════════════════════════
# Uniform Replay Buffer
# ═══════════════════════════════════════════════════════════════════
class UniformReplayBuffer:
    """Simple ring-buffer with uniform sampling (for vanilla DQN)."""

    def __init__(self, capacity: int):
        self.capacity = int(capacity)
        self.buffer = []
        self.pos = 0

    def push(self, s, a, r, ns, d):
        transition = (s, a, r, ns, d)
        if len(self.buffer) < self.capacity:
            self.buffer.append(transition)
        else:
            self.buffer[self.pos] = transition
        self.pos = (self.pos + 1) % self.capacity

    def sample(self, batch_size: int):
        batch = random.sample(self.buffer, batch_size)
        s, a, r, ns, d = map(np.stack, zip(*batch))
        return s, a, r, ns, d

    def __len__(self):
        return len(self.buffer)


# ═══════════════════════════════════════════════════════════════════
# Prioritised Replay Buffer
# ═══════════════════════════════════════════════════════════════════
class PrioritizedReplayBuffer:
    """SumTree-backed PER buffer (for Dueling DQN & Rainbow)."""

    def __init__(self, capacity: int, alpha: float):
        self.capacity = int(capacity)
        self.alpha = alpha
        self.tree = SumTree(capacity)
        self.max_priority = 1.0

    def push(self, s, a, r, ns, d):
        self.tree.add(self.max_priority ** self.alpha, (s, a, r, ns, d))

    def sample(self, batch_size: int, beta: float):
        batch, idxs, priorities = [], [], []
        total = max(self.tree.total, 1e-8)
        segment = total / batch_size

        for i in range(batch_size):
            lo = segment * i
            hi = segment * (i + 1)
            s = random.uniform(lo, hi)
            idx, p, data = self.tree.get(s)
            batch.append(data)
            idxs.append(idx)
            priorities.append(max(p, 1e-8))

        probs = np.array(priorities) / max(total, 1e-8)
        is_weights = np.power(self.capacity * probs + 1e-8, -beta)
        is_weights /= is_weights.max()

        s, a, r, ns, d = map(np.stack, zip(*batch))
        return s, a, r, ns, d, idxs, is_weights.astype(np.float32)

    def update_priorities(self, idxs, priorities):
        for idx, p in zip(idxs, priorities):
            p = max(float(p), 1e-8)
            self.max_priority = max(self.max_priority, p)
            self.tree._update(idx, p ** self.alpha)

    def __len__(self):
        return self.tree.size


# ═══════════════════════════════════════════════════════════════════
# N-Step Return Buffer (helper for Rainbow)
# ═══════════════════════════════════════════════════════════════════
class NStepBuffer:
    """Accumulates n-step returns before pushing to main buffer."""

    def __init__(self, n: int, gamma: float):
        self.n = n
        self.gamma = gamma
        self.buffer = []

    def append(self, s, a, r, ns, d):
        self.buffer.append((s, a, r, ns, d))
        if len(self.buffer) < self.n:
            return None
        # Compute n-step return
        R = 0.0
        for i in reversed(range(self.n)):
            _, _, ri, _, di = self.buffer[i]
            R = ri + self.gamma * R * (1.0 - di)
        s0, a0, _, _, _ = self.buffer[0]
        _, _, _, ns_last, d_last = self.buffer[-1]
        self.buffer.pop(0)
        return (s0, a0, R, ns_last, d_last)

    def flush(self):
        """Flush remaining transitions at episode end."""
        results = []
        while len(self.buffer) > 0:
            R = 0.0
            for i in reversed(range(len(self.buffer))):
                _, _, ri, _, di = self.buffer[i]
                R = ri + self.gamma * R * (1.0 - di)
            s0, a0, _, _, _ = self.buffer[0]
            _, _, _, ns_last, d_last = self.buffer[-1]
            results.append((s0, a0, R, ns_last, d_last))
            self.buffer.pop(0)
        return results
