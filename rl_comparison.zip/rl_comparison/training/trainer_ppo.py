"""
PPO Trainer (Discrete actions).
On-policy: rollout buffer → GAE → clipped surrogate loss.
"""
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim

from models.ppo import PPOActorCritic
from training.curriculum import CurriculumSchedule


class RolloutBuffer:
    """Stores one rollout of transitions for PPO."""

    def __init__(self):
        self.obs = []
        self.actions = []
        self.log_probs = []
        self.rewards = []
        self.dones = []
        self.values = []

    def store(self, obs, action, log_prob, reward, done, value):
        self.obs.append(obs)
        self.actions.append(action)
        self.log_probs.append(log_prob)
        self.rewards.append(reward)
        self.dones.append(done)
        self.values.append(value)

    def clear(self):
        self.obs.clear()
        self.actions.clear()
        self.log_probs.clear()
        self.rewards.clear()
        self.dones.clear()
        self.values.clear()

    def __len__(self):
        return len(self.obs)


class PPOTrainer:
    def __init__(self, cfg, device, curriculum: CurriculumSchedule):
        self.cfg = cfg
        self.device = device
        self.curriculum = curriculum

        self.policy = PPOActorCritic(cfg.obs_dim, cfg.n_actions, cfg.hidden_size).to(device)
        self.opt = optim.Adam(self.policy.parameters(), lr=cfg.lr)

        self.rollout = RolloutBuffer()
        self.global_step = 0

    @property
    def name(self):
        return "ppo"

    def select_action(self, obs: np.ndarray):
        """Returns (action, log_prob, value) for rollout storage."""
        with torch.no_grad():
            t = torch.tensor(obs, dtype=torch.float32, device=self.device).unsqueeze(0)
            action, log_prob, _, value = self.policy.get_action_and_value(t)
        return int(action.item()), float(log_prob.item()), float(value.item())

    def store_transition(self, obs, action, log_prob, reward, done, value):
        self.rollout.store(obs, action, log_prob, reward, done, value)

    def should_update(self) -> bool:
        return len(self.rollout) >= self.cfg.ppo_rollout_len

    def update(self, next_obs: np.ndarray, next_done: bool):
        """Compute GAE and run PPO epochs."""
        if len(self.rollout) == 0:
            return

        with torch.no_grad():
            t = torch.tensor(next_obs, dtype=torch.float32, device=self.device).unsqueeze(0)
            next_value = float(self.policy.get_value(t).item())

        # ── Compute GAE ──
        obs = np.array(self.rollout.obs)
        actions = np.array(self.rollout.actions)
        old_log_probs = np.array(self.rollout.log_probs)
        rewards = np.array(self.rollout.rewards)
        dones = np.array(self.rollout.dones)
        values = np.array(self.rollout.values)

        T = len(rewards)
        advantages = np.zeros(T, dtype=np.float32)
        returns = np.zeros(T, dtype=np.float32)
        gae = 0.0

        for t in reversed(range(T)):
            if t == T - 1:
                next_val = next_value
                next_nonterminal = 1.0 - float(next_done)
            else:
                next_val = values[t + 1]
                next_nonterminal = 1.0 - dones[t + 1]
            delta = rewards[t] + self.cfg.gamma * next_val * next_nonterminal - values[t]
            gae = delta + self.cfg.gamma * self.cfg.ppo_gae_lambda * next_nonterminal * gae
            advantages[t] = gae
        returns = advantages + values

        # ── To tensors ──
        obs_t = torch.tensor(obs, dtype=torch.float32, device=self.device)
        act_t = torch.tensor(actions, dtype=torch.long, device=self.device)
        old_lp_t = torch.tensor(old_log_probs, dtype=torch.float32, device=self.device)
        ret_t = torch.tensor(returns, dtype=torch.float32, device=self.device)
        adv_t = torch.tensor(advantages, dtype=torch.float32, device=self.device)
        adv_t = (adv_t - adv_t.mean()) / (adv_t.std() + 1e-8)

        # ── PPO epochs ──
        batch_size = self.cfg.batch_size
        for _ in range(self.cfg.ppo_epochs):
            idxs = np.random.permutation(T)
            for start in range(0, T, batch_size):
                end = start + batch_size
                mb_idx = idxs[start:end]

                mb_obs = obs_t[mb_idx]
                mb_act = act_t[mb_idx]
                mb_old_lp = old_lp_t[mb_idx]
                mb_ret = ret_t[mb_idx]
                mb_adv = adv_t[mb_idx]

                _, new_lp, entropy, new_val = self.policy.get_action_and_value(mb_obs, mb_act)

                ratio = torch.exp(new_lp - mb_old_lp)
                surr1 = ratio * mb_adv
                surr2 = torch.clamp(ratio, 1.0 - self.cfg.ppo_clip, 1.0 + self.cfg.ppo_clip) * mb_adv
                policy_loss = -torch.min(surr1, surr2).mean()
                value_loss = nn.SmoothL1Loss()(new_val, mb_ret)
                entropy_loss = -entropy.mean()

                loss = (policy_loss
                        + self.cfg.ppo_value_coef * value_loss
                        + self.cfg.ppo_entropy_coef * entropy_loss)

                self.opt.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.policy.parameters(), self.cfg.grad_clip_norm)
                self.opt.step()

        self.rollout.clear()

    def step_done(self):
        self.global_step += 1

    def get_eval_action(self, obs: np.ndarray) -> int:
        with torch.no_grad():
            t = torch.tensor(obs, dtype=torch.float32, device=self.device).unsqueeze(0)
            return int(self.policy.get_deterministic_action(t).item())

    def save(self, path: str):
        torch.save(self.policy.state_dict(), path)

    def load(self, path: str):
        self.policy.load_state_dict(torch.load(path, map_location=self.device, weights_only=True))
