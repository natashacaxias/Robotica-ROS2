"""
Comparative plot generation for the RL comparison experiment.
Reads all CSV logs from logs/ and produces publication-quality figures.

Usage:  python plots/generate_plots.py
"""
import os
import sys
import csv
import glob
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from scipy import stats

# Ensure project root is on path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from training.config import CONFIG

# ═══════════════════════════════════════════════════════════════
# Style
# ═══════════════════════════════════════════════════════════════
ALGO_COLORS = {
    "dqn": "#4C72B0",
    "dueling_dqn": "#DD8452",
    "ppo": "#55A868",
    "rainbow": "#C44E52",
}
ALGO_LABELS = {
    "dqn": "DQN",
    "dueling_dqn": "Dueling DQN",
    "ppo": "PPO",
    "rainbow": "Rainbow DQN",
}

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.size": 11,
    "axes.titlesize": 13,
    "axes.labelsize": 12,
    "legend.fontsize": 10,
    "figure.dpi": 150,
    "savefig.dpi": 300,
    "savefig.bbox_inches": "tight",
})


def _logs_dir():
    return os.path.join(os.path.dirname(__file__), "..", "logs")


def _out_dir():
    d = os.path.join(os.path.dirname(__file__), "..", "plots", "output")
    os.makedirs(d, exist_ok=True)
    return d


# ═══════════════════════════════════════════════════════════════
# 1. Learning Curves (reward over steps, mean ± std)
# ═══════════════════════════════════════════════════════════════
def plot_learning_curves():
    fig, ax = plt.subplots(figsize=(10, 5.5))

    for algo in CONFIG.algorithms:
        all_series = []
        for seed in CONFIG.seeds:
            path = os.path.join(_logs_dir(), f"{algo}_seed{seed}", "training_rewards.csv")
            if not os.path.exists(path):
                continue
            df = pd.read_csv(path)
            # Bin rewards by step (10k intervals)
            df["bin"] = (df["step"] // 10000) * 10000
            binned = df.groupby("bin")["episode_reward"].mean()
            all_series.append(binned)

        if not all_series:
            continue

        # Align series
        combined = pd.concat(all_series, axis=1)
        mean = combined.mean(axis=1)
        std = combined.std(axis=1).fillna(0)
        steps = mean.index.values

        color = ALGO_COLORS[algo]
        ax.plot(steps, mean.values, label=ALGO_LABELS[algo], color=color, linewidth=2)
        ax.fill_between(steps, (mean - std).values, (mean + std).values,
                        alpha=0.2, color=color)

    ax.set_xlabel("Training Steps")
    ax.set_ylabel("Episode Reward (mean ± std)")
    ax.set_title("Learning Curves — Reward Convergence")
    ax.legend(loc="lower right")
    ax.grid(True, alpha=0.3)
    ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x/1e6:.1f}M" if x >= 1e6 else f"{x/1e3:.0f}k"))
    plt.savefig(os.path.join(_out_dir(), "learning_curves.png"))
    plt.close()
    print("[OK] learning_curves.png")


# ═══════════════════════════════════════════════════════════════
# 2. Bar plots: Success Rate and Collision Rate
# ═══════════════════════════════════════════════════════════════
def _load_final_eval_results():
    """Load the last eval checkpoint for each algo × seed."""
    results = {}  # algo → list of dicts
    for algo in CONFIG.algorithms:
        algo_results = []
        for seed in CONFIG.seeds:
            path = os.path.join(_logs_dir(), f"{algo}_seed{seed}", "eval_metrics.csv")
            if not os.path.exists(path):
                continue
            df = pd.read_csv(path)
            last_step = df["step"].max()
            last = df[df["step"] == last_step]
            seed_res = {}
            for _, row in last.iterrows():
                seed_res[row["scenario"]] = {
                    "success_rate": float(row["success_rate"]),
                    "collision_rate": float(row["collision_rate"]),
                    "timeout_rate": float(row["timeout_rate"]),
                    "avg_reward": float(row["avg_reward"]),
                }
            algo_results.append(seed_res)
        results[algo] = algo_results
    return results


def plot_bar_success():
    results = _load_final_eval_results()
    scenarios = ["easy", "medium", "hard"]
    fig, ax = plt.subplots(figsize=(10, 5.5))

    x = np.arange(len(scenarios))
    width = 0.18

    for i, algo in enumerate(CONFIG.algorithms):
        means, stds = [], []
        for scen in scenarios:
            vals = [r[scen]["success_rate"] for r in results.get(algo, []) if scen in r]
            means.append(np.mean(vals) * 100 if vals else 0)
            stds.append(np.std(vals) * 100 if vals else 0)
        offset = (i - 1.5) * width
        bars = ax.bar(x + offset, means, width, yerr=stds, capsize=4,
                      label=ALGO_LABELS[algo], color=ALGO_COLORS[algo], alpha=0.85)

    ax.set_xlabel("Scenario")
    ax.set_ylabel("Success Rate (%)")
    ax.set_title("Final Success Rate by Scenario")
    ax.set_xticks(x)
    ax.set_xticklabels([s.capitalize() for s in scenarios])
    ax.set_ylim(0, 110)
    ax.legend()
    ax.grid(True, alpha=0.2, axis="y")
    plt.savefig(os.path.join(_out_dir(), "bar_success_rate.png"))
    plt.close()
    print("[OK] bar_success_rate.png")


def plot_bar_collision():
    results = _load_final_eval_results()
    scenarios = ["easy", "medium", "hard"]
    fig, ax = plt.subplots(figsize=(10, 5.5))

    x = np.arange(len(scenarios))
    width = 0.18

    for i, algo in enumerate(CONFIG.algorithms):
        means, stds = [], []
        for scen in scenarios:
            vals = [r[scen]["collision_rate"] for r in results.get(algo, []) if scen in r]
            means.append(np.mean(vals) * 100 if vals else 0)
            stds.append(np.std(vals) * 100 if vals else 0)
        offset = (i - 1.5) * width
        ax.bar(x + offset, means, width, yerr=stds, capsize=4,
               label=ALGO_LABELS[algo], color=ALGO_COLORS[algo], alpha=0.85)

    ax.set_xlabel("Scenario")
    ax.set_ylabel("Collision Rate (%)")
    ax.set_title("Collision Rate by Scenario")
    ax.set_xticks(x)
    ax.set_xticklabels([s.capitalize() for s in scenarios])
    ax.legend()
    ax.grid(True, alpha=0.2, axis="y")
    plt.savefig(os.path.join(_out_dir(), "bar_collision_rate.png"))
    plt.close()
    print("[OK] bar_collision_rate.png")


# ═══════════════════════════════════════════════════════════════
# 3. Eval success over training steps (line plot)
# ═══════════════════════════════════════════════════════════════
def plot_eval_success_over_time():
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.5), sharey=True)
    scenarios = ["easy", "medium", "hard"]

    for ax, scen in zip(axes, scenarios):
        for algo in CONFIG.algorithms:
            all_series = []
            for seed in CONFIG.seeds:
                path = os.path.join(_logs_dir(), f"{algo}_seed{seed}", "eval_metrics.csv")
                if not os.path.exists(path):
                    continue
                df = pd.read_csv(path)
                scen_df = df[df["scenario"] == scen].set_index("step")["success_rate"]
                all_series.append(scen_df)

            if not all_series:
                continue
            combined = pd.concat(all_series, axis=1)
            mean = combined.mean(axis=1)
            std = combined.std(axis=1).fillna(0)

            color = ALGO_COLORS[algo]
            ax.plot(mean.index, mean.values * 100, label=ALGO_LABELS[algo],
                    color=color, linewidth=2)
            ax.fill_between(mean.index, (mean - std).values * 100,
                            (mean + std).values * 100, alpha=0.15, color=color)

        ax.set_title(f"{scen.capitalize()} Scenario")
        ax.set_xlabel("Training Steps")
        ax.set_ylabel("Success Rate (%)" if scen == "easy" else "")
        ax.grid(True, alpha=0.2)
        ax.xaxis.set_major_formatter(mticker.FuncFormatter(
            lambda x, _: f"{x/1e6:.1f}M" if x >= 1e6 else f"{x/1e3:.0f}k"))

    axes[0].legend(loc="lower right", fontsize=9)
    plt.suptitle("Evaluation Success Rate During Training", fontsize=14, y=1.02)
    plt.tight_layout()
    plt.savefig(os.path.join(_out_dir(), "eval_success_over_time.png"))
    plt.close()
    print("[OK] eval_success_over_time.png")


# ═══════════════════════════════════════════════════════════════
# 4. Generalization performance table
# ═══════════════════════════════════════════════════════════════
def generate_generalization_table():
    rows = []
    for algo in CONFIG.algorithms:
        vals = {"success": [], "collision": [], "wall_collision": [], "timeout": []}
        for seed in CONFIG.seeds:
            path = os.path.join(_logs_dir(), f"{algo}_seed{seed}", "generalization.csv")
            if not os.path.exists(path):
                continue
            df = pd.read_csv(path)
            vals["success"].append(float(df["success_rate"].iloc[0]))
            vals["collision"].append(float(df["collision_rate"].iloc[0]))
            vals["wall_collision"].append(float(df["wall_collision_rate"].iloc[0]))
            vals["timeout"].append(float(df["timeout_rate"].iloc[0]))

        if not vals["success"]:
            continue
        rows.append({
            "Algorithm": ALGO_LABELS[algo],
            "Success (%)": f"{np.mean(vals['success'])*100:.1f} ± {np.std(vals['success'])*100:.1f}",
            "Collision (%)": f"{np.mean(vals['collision'])*100:.1f} ± {np.std(vals['collision'])*100:.1f}",
            "Wall Col. (%)": f"{np.mean(vals['wall_collision'])*100:.1f} ± {np.std(vals['wall_collision'])*100:.1f}",
            "Timeout (%)": f"{np.mean(vals['timeout'])*100:.1f} ± {np.std(vals['timeout'])*100:.1f}",
        })

    if not rows:
        print("[SKIP] No generalization data.")
        return

    df_table = pd.DataFrame(rows)
    # Save as CSV
    df_table.to_csv(os.path.join(_out_dir(), "generalization_table.csv"), index=False)
    # Save as LaTeX
    with open(os.path.join(_out_dir(), "generalization_table.tex"), "w") as f:
        f.write(df_table.to_latex(index=False, escape=False))
    print("[OK] generalization_table.csv / .tex")


# ═══════════════════════════════════════════════════════════════
# 5. Statistical tests (Mann-Whitney U)
# ═══════════════════════════════════════════════════════════════
def run_statistical_tests():
    """Pairwise Mann-Whitney U tests on generalization success rates."""
    algo_vals = {}
    for algo in CONFIG.algorithms:
        vals = []
        for seed in CONFIG.seeds:
            path = os.path.join(_logs_dir(), f"{algo}_seed{seed}", "generalization.csv")
            if not os.path.exists(path):
                continue
            df = pd.read_csv(path)
            vals.append(float(df["success_rate"].iloc[0]))
        if vals:
            algo_vals[algo] = vals

    if len(algo_vals) < 2:
        print("[SKIP] Not enough data for statistical tests.")
        return

    rows = []
    algos = list(algo_vals.keys())
    n_comparisons = len(algos) * (len(algos) - 1) // 2

    for i in range(len(algos)):
        for j in range(i + 1, len(algos)):
            a, b = algos[i], algos[j]
            va, vb = algo_vals[a], algo_vals[b]
            if len(va) < 2 or len(vb) < 2:
                continue
            stat, p = stats.mannwhitneyu(va, vb, alternative="two-sided")
            # Bonferroni correction
            p_corrected = min(p * n_comparisons, 1.0)
            rows.append({
                "Pair": f"{ALGO_LABELS[a]} vs {ALGO_LABELS[b]}",
                "U-statistic": f"{stat:.2f}",
                "p-value": f"{p:.4f}",
                "p-corrected": f"{p_corrected:.4f}",
                "significant (α=0.05)": "Yes" if p_corrected < 0.05 else "No",
            })

    if rows:
        df = pd.DataFrame(rows)
        df.to_csv(os.path.join(_out_dir(), "statistical_tests.csv"), index=False)
        print("[OK] statistical_tests.csv")
        print(df.to_string(index=False))
    else:
        print("[SKIP] Insufficient samples for statistical tests.")


# ═══════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════
def main():
    print("═" * 50)
    print("  GENERATING COMPARISON PLOTS")
    print("═" * 50)

    plot_learning_curves()
    plot_bar_success()
    plot_bar_collision()
    plot_eval_success_over_time()
    generate_generalization_table()
    run_statistical_tests()

    print(f"\nAll plots saved to: {os.path.abspath(_out_dir())}")


if __name__ == "__main__":
    main()
